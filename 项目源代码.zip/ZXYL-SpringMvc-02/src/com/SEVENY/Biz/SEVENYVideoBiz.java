/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.SEVENY.Biz;

import com.SEVENY.Table.SEVENYVideoTable;
import java.util.List;

/**
 
 * @author Lenovo
 */
public interface SEVENYVideoBiz {
    //增
    int insertVideo(SEVENYVideoTable svideo);
    //删
    int deleteVideo(SEVENYVideoTable svideo);
    //改
    int updateVideo(SEVENYVideoTable svideo);
    //查
     //1.通过上传视频的用户名查找视频的list
    List<SEVENYVideoTable> getVideoByUsername(String username);
     //2.通过视频的名称来查找视频的list
    List<SEVENYVideoTable> getVideoByVideoName(String videoname);
     //3.通过视频的导演来查找视频的list
    List<SEVENYVideoTable> getVideoByVideoAuthor(String videoauthor);
     //4.通过视频评分的从高到低来存到list中
    List<SEVENYVideoTable> getVideoByVideoScore();
     //5.通过视频日期的从新到老来存到list中
    List<SEVENYVideoTable> getVideoByUpDate();
     //6.查找通过审核并且未放入回收站的视频
    List<SEVENYVideoTable> getVideoByThrouthOkShow();
     //7.查找未通过审核并且未放入回收站的视频
    List<SEVENYVideoTable> getVideoByNotThrouthOkShow();
     //8.查找还未审核并且未放入回收站的视频
    List<SEVENYVideoTable> getVideoByNoOkShow();
     //9.查找放入回收站的视频 
    List<SEVENYVideoTable> getVideoByNotShow(String username);
     //10.通过演员like找到视频的list
    List<SEVENYVideoTable> getVideoByYanYuan(String yyname);
     //11.通过语言找到视频的list
    List<SEVENYVideoTable> getVideoByVideoLanguage(String language);
     //12.通过视频的类型like找到视频的list 
    List<SEVENYVideoTable> getVideoByVideoType(String type);
     //13.通过视频的已经被审核（过/不过），得到指定的管理员审核过的视频的list
    List<SEVENYVideoTable> getBookByVideoAdmin(String admin);
    
     //通过电影名称和上传的用户名来查找此电影
    SEVENYVideoTable getOneVideoByUpUsernameAndVideoName(String username,String videoname);
    
     List<SEVENYVideoTable> getVideoByVideoScoreTop10();
     
     SEVENYVideoTable getVideoByVideoId(int id);
     
     List<SEVENYVideoTable> getVideoByVideoStartDateTop10();
     
     int getVideoSize();
     
      List<SEVENYVideoTable> getListByPageNoOrderByUpDate(int pageNo, int pageSize);
      
      List<SEVENYVideoTable> getVideoByUsernameThoughShow(String username);
      
       List<SEVENYVideoTable> getVideoByNotThrouthOkShowByUsername(String username);
}

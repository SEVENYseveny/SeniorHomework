package com.SEVENY.Biz;

import java.util.List;

import com.SEVENY.Table.SEVENYNewsTable;

public interface SEVENYNewsBiz {
	//增
    int insertNews(SEVENYNewsTable snews);
    
List<SEVENYNewsTable> getNewsByNewsTimeTop10();
    
List<SEVENYNewsTable> getNewsByUpDate();
    
    SEVENYNewsTable getNewsByNewsId(int id);
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.SEVENY.Biz;

import com.SEVENY.Table.SEVENYMusicTable;
import java.util.List;

/**
 * @author Lenovo
 */
public interface SEVENYMusicBiz {
    //增
    int insertMusic(SEVENYMusicTable smusic);
    //删
    int deleteMusic(SEVENYMusicTable smusic);
    //改
    int updateMusic(SEVENYMusicTable smusic);
    
    //查
     //1.通过上传音乐的用户名查找音乐的list
    List<SEVENYMusicTable> getMusicByUpUsername(String username);
     //2.通过音乐的名称来查找音乐的list
    List<SEVENYMusicTable> getMusicByMusicName(String musicname);
     //3.通过音乐的演唱者作者来查找音乐的list
    List<SEVENYMusicTable> getMusicByMusicSinger(String singer);
     //4.通过音乐评分的从高到低来存到list中
    List<SEVENYMusicTable> getMusicByMusicScore();
     //5.通过音乐日期的从新到老来存到list中
    List<SEVENYMusicTable> getMusicByMusicDate();
     //6.查找通过审核并且未放入回收站的音乐
    List<SEVENYMusicTable> getMusicByThroughOkShow();
     //7.查找未通过审核并且未放入回收站的音乐
    List<SEVENYMusicTable> getMusicByNotThroughOkShow();
     //8.查找还未审核并且未放入回收站的音乐
    List<SEVENYMusicTable> getMusicByNoOkShow();
     //9.查找放入回收站的视频 
    List<SEVENYMusicTable> getMusicByNotShow(String username);
     //10.通过音乐的词作者查找音乐的list
    List<SEVENYMusicTable> getMusicByMusicWord(String musicword);
     //11.通过音乐的曲作者找到音乐的list
    List<SEVENYMusicTable> getMusicByMusicSong(String song);
     //12.通过音乐的类型like找到音乐的list 
    List<SEVENYMusicTable> getMusicByMusicType(String musictype);
     //13.通过音乐的已经被审核（过/不过），得到指定的管理员审核过的音乐的list
    List<SEVENYMusicTable> getMusicByMusicAdmin(String admin);
     //14.通过音乐专辑查找音乐的list
    List<SEVENYMusicTable> getMusicByMusicAlbum(String album);
    //通过电影名称和上传的用户名来查找此电影
    SEVENYMusicTable getOneMusicByUpUsernameAndMusicName(String username,String musicname);
    
      List<SEVENYMusicTable> getMusicByMusicScoreTop10();
      
      SEVENYMusicTable getMusicByMusicId(int id);
      
      int getMusicSize();
      
       List<SEVENYMusicTable> getListByPageNoOrderByUpDate(int pageNo, int pageSize);
       
       List<SEVENYMusicTable> getMusicByUsernameThoughShow(String username);
       
         List<SEVENYMusicTable> getMusicByNotThroughOkShowByUsername(String username);
}

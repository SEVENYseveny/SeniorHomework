package com.SEVENY.Biz;

import com.SEVENY.Table.SEVENYAdminLoginTable;

public interface SEVENYAdminLoginBiz {

	
	 SEVENYAdminLoginTable getAdminByName(String name);
}

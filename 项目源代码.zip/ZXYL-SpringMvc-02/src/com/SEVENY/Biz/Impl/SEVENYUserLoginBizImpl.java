
package com.SEVENY.Biz.Impl;

import com.SEVENY.Biz.SEVENYUserLoginBiz;
import com.SEVENY.Dao.SEVENYUserLoginDao;
import com.SEVENY.Dao.Impl.SEVENYUserLoginDaoImpl;
import com.SEVENY.Table.SEVENYUserLoginTable; 
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

/**
 
 * @author Lenovo
 */
@Service(value="sulbi")
public class SEVENYUserLoginBizImpl implements SEVENYUserLoginBiz {
	
	@Resource(name="suldi")
	private  SEVENYUserLoginDao sul;  
	
	@Override
    public int insert(SEVENYUserLoginTable s) { 
        SEVENYUserLoginTable student = sul.getUserByTelNumber(s.getUserTelNumber());//注册插入之前先查看是否已经存在这个用户
        if(null!=student){
            return -1;  //如果存在这个用户，就返回-1；
        }else{
            return sul.insert(s);
        }
        
    }

    @Override
    public int update(SEVENYUserLoginTable s) { 
        SEVENYUserLoginTable student = sul.getUserByTelNumber(s.getUserTelNumber());//修改之前先查看是否已经存在这个用户
        if(null==student){
            return -1; //如果不存在此用户  返回-1；
        }else{
            return sul.update(s);
        }
            
    }

    @Override
    public SEVENYUserLoginTable getUserByTelNumber(String tel) { 
        return sul.getUserByTelNumber(tel);
    }

    @Override
    public SEVENYUserLoginTable getUserByName(String name) { 
        return sul.getUserByName(name);
    }

    @Override
    public List<SEVENYUserLoginTable> getUserByAddress(String add) { 
       return sul.getUserByAddress(add);
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.SEVENY.Biz.Impl;

import com.SEVENY.Dao.SEVENYVideoDao;
import com.SEVENY.Dao.Impl.SEVENYVideoDaoImpl;
import com.SEVENY.Table.SEVENYVideoTable;
import com.SEVENY.Biz.SEVENYVideoBiz;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

/**
 *
 * @author Lenovo
 */
@Service(value="svbi")
public class SEVENYVideoBizImpl implements SEVENYVideoBiz{

	
	@Resource(name="svdi")
	private SEVENYVideoDao svd;
	
    @Override
    public int insertVideo(SEVENYVideoTable svideo) { 
       return svd.insertVideo(svideo);
    }

    @Override
    public int deleteVideo(SEVENYVideoTable svideo) { 
        return svd.deleteVideo(svideo);             
    }

    @Override
    public int updateVideo(SEVENYVideoTable svideo) { 
        return svd.updateVideo(svideo);          
    }

    @Override
    public List<SEVENYVideoTable> getVideoByUsername(String username) { 
        return svd.getVideoByUsername(username);             
    }

    @Override
    public List<SEVENYVideoTable> getVideoByVideoName(String videoname) { 
        return svd.getVideoByVideoName(videoname);               
    }

    @Override
    public List<SEVENYVideoTable> getVideoByVideoAuthor(String videoauthor) { 
         return svd.getVideoByVideoAuthor(videoauthor);               
    }

    @Override
    public List<SEVENYVideoTable> getVideoByVideoScore() { 
         return svd.getVideoByVideoScore();      
    }
    
    @Override
    public List<SEVENYVideoTable> getVideoByVideoScoreTop10() { 
         return svd.getVideoByVideoScoreTop10();      
    }

    @Override
    public List<SEVENYVideoTable> getVideoByUpDate() { 
         return svd.getVideoByUpDate();             
    }

    @Override
    public List<SEVENYVideoTable> getVideoByThrouthOkShow() { 
         return svd.getVideoByThrouthOkShow();            
    }

    @Override
    public List<SEVENYVideoTable> getVideoByNotThrouthOkShow() { 
         return svd.getVideoByNotThrouthOkShow();            
    }

    @Override
    public List<SEVENYVideoTable> getVideoByNoOkShow() { 
         return svd.getVideoByNoOkShow();             
    }

    @Override
    public List<SEVENYVideoTable> getVideoByNotShow(String username) { 
         return svd.getVideoByNotShow(username);           
    }

    @Override
    public List<SEVENYVideoTable> getVideoByYanYuan(String yyname) { 
         return svd.getVideoByYanYuan(yyname);             
    }

    @Override
    public List<SEVENYVideoTable> getVideoByVideoLanguage(String language) { 
         return svd.getVideoByVideoLanguage(language);            
    }

    @Override
    public List<SEVENYVideoTable> getVideoByVideoType(String type) { 
         return svd.getVideoByVideoType(type);             
    }

    @Override
    public List<SEVENYVideoTable> getBookByVideoAdmin(String admin) { 
         return svd.getBookByVideoAdmin(admin);              
    }

    @Override
    public SEVENYVideoTable getOneVideoByUpUsernameAndVideoName(String username, String videoname) {
         return svd.getOneVideoByUpUsernameAndVideoName(username,videoname);            
    }

    @Override
    public SEVENYVideoTable getVideoByVideoId(int id) { 
        return svd.getVideoByVideoId(id);

    }
    
    @Override
    public List<SEVENYVideoTable> getVideoByVideoStartDateTop10() {
        return svd.getVideoByVideoStartDateTop10();
    }

    @Override
    public int getVideoSize() { 
          return svd.getVideoSize();
    }

    @Override
    public List<SEVENYVideoTable> getListByPageNoOrderByUpDate(int pageNo, int pageSize) {
          return svd.getListByPageNoOrderByUpDate(pageNo, pageSize);
    }

    @Override
    public List<SEVENYVideoTable> getVideoByUsernameThoughShow(String username) {
          return svd.getVideoByUsernameThoughShow(username);
    }

    @Override
    public List<SEVENYVideoTable> getVideoByNotThrouthOkShowByUsername(String username) {
          return svd.getVideoByNotThrouthOkShowByUsername(username);
    }
}

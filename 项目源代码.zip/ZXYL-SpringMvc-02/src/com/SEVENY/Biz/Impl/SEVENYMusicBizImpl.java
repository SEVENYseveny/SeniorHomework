/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.SEVENY.Biz.Impl;

import com.SEVENY.Dao.SEVENYMusicDao;
import com.SEVENY.Dao.Impl.SEVENYMusicDaoImpl;
import com.SEVENY.Table.SEVENYMusicTable;
import com.SEVENY.Biz.SEVENYMusicBiz;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

/**
 
 * @author Lenovo
 */
@Service(value="smbi")
public class SEVENYMusicBizImpl implements SEVENYMusicBiz{

	@Resource(name="smdi")
	private SEVENYMusicDao smd;
	
    @Override
    public int insertMusic(SEVENYMusicTable smusic) { 
        return smd.insertMusic(smusic);
    }

    @Override
    public int deleteMusic(SEVENYMusicTable smusic) { 
        return smd.deleteMusic(smusic);           
    }

    @Override
    public int updateMusic(SEVENYMusicTable smusic) { 
        return smd.updateMusic(smusic);            
    }

    @Override
    public List<SEVENYMusicTable> getMusicByUpUsername(String username) { 
        return smd.getMusicByUpUsername(username);           
    }

    @Override
    public List<SEVENYMusicTable> getMusicByMusicName(String musicname) { 
        return smd.getMusicByMusicName(musicname);           
    }

    @Override
    public List<SEVENYMusicTable> getMusicByMusicSinger(String singer) { 
        return smd.getMusicByMusicSinger(singer);           
    }

    @Override
    public List<SEVENYMusicTable> getMusicByMusicScore() { 
        return smd.getMusicByMusicScore();            
    }
    
    @Override
    public List<SEVENYMusicTable> getMusicByMusicScoreTop10() { 
        return smd.getMusicByMusicScoreTop10();            
    }

    @Override
    public List<SEVENYMusicTable> getMusicByMusicDate() { 
        return smd.getMusicByMusicDate();            
    }

    @Override
    public List<SEVENYMusicTable> getMusicByThroughOkShow() { 
        return smd.getMusicByThroughOkShow();           
    }

    @Override
    public List<SEVENYMusicTable> getMusicByNotThroughOkShow() { 
        return smd.getMusicByNotThroughOkShow();           
    }

    @Override
    public List<SEVENYMusicTable> getMusicByNoOkShow() { 
        return smd.getMusicByNoOkShow();           
    }

    @Override
    public List<SEVENYMusicTable> getMusicByNotShow(String username) { 
        return smd.getMusicByNotShow(username);          
    }

    @Override
    public List<SEVENYMusicTable> getMusicByMusicWord(String musicword) { 
        return smd.getMusicByMusicWord(musicword);        
    }

    @Override
    public List<SEVENYMusicTable> getMusicByMusicSong(String song) { 
        return smd.getMusicByMusicSong(song);            
    }

    @Override
    public List<SEVENYMusicTable> getMusicByMusicType(String musictype) { 
        return smd.getMusicByMusicType(musictype);            
    }

    @Override
    public List<SEVENYMusicTable> getMusicByMusicAdmin(String admin) { 
        return smd.getMusicByMusicAdmin(admin);             
    }

    @Override
    public List<SEVENYMusicTable> getMusicByMusicAlbum(String album) { 
        return smd.getMusicByMusicAlbum(album);            
    }

    @Override
    public SEVENYMusicTable getOneMusicByUpUsernameAndMusicName(String username, String musicname) {
        return smd.getOneMusicByUpUsernameAndMusicName(username,musicname);            
    }

    @Override
    public SEVENYMusicTable getMusicByMusicId(int id) { 
         return smd.getMusicByMusicId(id);
    }

    @Override
    public int getMusicSize() { 
         return smd.getMusicSize();
    }

    @Override
    public List<SEVENYMusicTable> getListByPageNoOrderByUpDate(int pageNo, int pageSize) { 
         return smd.getListByPageNoOrderByUpDate(pageNo, pageSize);
    }

    @Override
    public List<SEVENYMusicTable> getMusicByUsernameThoughShow(String username) { 
         return smd.getMusicByUsernameThoughShow(username);
    }

    @Override
    public List<SEVENYMusicTable> getMusicByNotThroughOkShowByUsername(String username) { 
         return smd.getMusicByNotThroughOkShowByUsername(username);
    }
    
}

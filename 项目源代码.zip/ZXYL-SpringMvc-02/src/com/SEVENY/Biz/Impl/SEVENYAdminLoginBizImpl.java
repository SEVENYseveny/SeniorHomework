package com.SEVENY.Biz.Impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.SEVENY.Biz.SEVENYAdminLoginBiz;
import com.SEVENY.Dao.SEVENYAdminLoginDao;
import com.SEVENY.Table.SEVENYAdminLoginTable;

@Service(value="salbi")
public class SEVENYAdminLoginBizImpl implements SEVENYAdminLoginBiz {

	@Resource(name="saldi")
	private SEVENYAdminLoginDao sald;
	
	@Override
	public SEVENYAdminLoginTable getAdminByName(String name) {
		return sald.getAdminByName(name);
	}

}

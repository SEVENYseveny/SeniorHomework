package com.SEVENY.Biz.Impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.SEVENY.Biz.SEVENYNotesEvaluateBiz;
import com.SEVENY.Dao.SEVENYNotesEvaluateDao;
import com.SEVENY.Table.SEVENYNotesEvaluateTable;

@Service(value="snebi")
public class SEVENYNotesEvaluateBizImpl implements SEVENYNotesEvaluateBiz{
   
	@Resource(name="snedi")
	private SEVENYNotesEvaluateDao snoted;
	
	
	@Override
    public int insertZan(SEVENYNotesEvaluateTable snotee) { 
         return snoted.insertZan(snotee);
    }

    @Override
    public int findZanByIdUserName(int id, String username) { 
        return snoted.findZanByIdUserName(id, username);
    }

    @Override
    public List<SEVENYNotesEvaluateTable> getAllZanByNoteId(int id) { 
        return snoted.getAllZanByNoteId(id);
    }

    @Override
    public int deleteZan(SEVENYNotesEvaluateTable snotee) { 
        return snoted.deleteZan(snotee);
    }
}

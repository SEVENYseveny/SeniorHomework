/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.SEVENY.Biz.Impl;

import com.SEVENY.Dao.SEVENYBookDao;
import com.SEVENY.Dao.Impl.SEVENYBookDaoImpl;
import com.SEVENY.Table.SEVENYBookTable;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.SEVENY.Biz.SEVENYBookBiz;

/**
 
 * @author Lenovo
 */
@Service(value="sbbi")
public class SEVENYBookBizImpl implements SEVENYBookBiz {

	@Resource(name="sbdi")
	private SEVENYBookDao sbd;
	
    @Override
    public int insertBook(SEVENYBookTable sbook) { 
        return sbd.insertBook(sbook);
    }

    @Override
    public int deleteBook(SEVENYBookTable sbook) { 
        return sbd.deleteBook(sbook);
    }

    @Override
    public int update(SEVENYBookTable sbook) { 
        return sbd.update(sbook);
    }

    @Override
    public List<SEVENYBookTable> getBookByUpUsername(String username) { 
        return sbd.getBookByUpUsername(username);
    }

    @Override
    public List<SEVENYBookTable> getBookByUpBookName(String bookname) { 
        return sbd.getBookByUpBookName(bookname);           
    }

    @Override
    public List<SEVENYBookTable> getBookByUpBookAuthor(String bookauthor) { 
        return sbd.getBookByUpBookAuthor(bookauthor);             
    }

    @Override
    public List<SEVENYBookTable> getBookByBookScore() { 
        return sbd.getBookByBookScore();                       
    }
    
     @Override
    public List<SEVENYBookTable> getBookByBookScoreTop10() { 
        return sbd.getBookByBookScoreTop10();                       
    }

    @Override
    public List<SEVENYBookTable> getBookByUpDate() { 
        return sbd.getBookByUpDate();                
    }

    @Override
    public List<SEVENYBookTable> getBookByOkThoughShow() { 
        return sbd.getBookByOkThoughShow();                
    }

    @Override
    public List<SEVENYBookTable> getBookByNotThoughShow() { 
        return sbd.getBookByNotThoughShow();               
    }

    @Override
    public List<SEVENYBookTable> getBookByThoughShow() { 
        return sbd.getBookByThoughShow();                
    }

    @Override
    public List<SEVENYBookTable> getBookByNotShow() { 
        return sbd.getBookByNotShow();                
    }

    @Override
    public List<SEVENYBookTable> getBookByBookPress(String press) { 
        return sbd.getBookByBookPress(press);               
    }

    @Override
    public List<SEVENYBookTable> getBookByCountry(String country) { 
        return sbd.getBookByCountry(country);              
    }

    @Override
    public List<SEVENYBookTable> getBookByBookAdmin(String admin) { 
        return sbd.getBookByBookAdmin(admin);              
    }

    @Override
    public SEVENYBookTable getOneBookByUpUsernameAndBookName(String username, String bookname) {
        return sbd.getOneBookByUpUsernameAndBookName(username, bookname);
    }

    @Override
    public SEVENYBookTable getBookByBookId(int id) {
        return sbd.getBookByBookId(id);
    }
    
    @Override 
    public long getBookSize()
    {
        return sbd.getBookSize();
    }

    @Override
    public List<SEVENYBookTable> getListByPageNoOrderByUpDate(int pageNo, int pageSize) {
        return sbd.getListByPageNoOrderByUpDate(pageNo, pageSize);
    }
    @Override
    public List<SEVENYBookTable> getBookByUsernameThoughShow(String username){
        return sbd.getBookByUsernameThoughShow(username);
    }

    @Override
    public List<SEVENYBookTable> getBookByNotShowUsername(String username) {
        return sbd.getBookByNotShowUsername(username);
    }

    @Override
    public List<SEVENYBookTable> getBookByNotThoughShowByUsername(String username) {
        return sbd.getBookByNotThoughShowByUsername(username);
    }
    
}

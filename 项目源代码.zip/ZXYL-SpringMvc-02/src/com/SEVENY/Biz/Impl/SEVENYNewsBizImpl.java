package com.SEVENY.Biz.Impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.SEVENY.Biz.SEVENYNewsBiz;
import com.SEVENY.Dao.SEVENYNewsDao;
import com.SEVENY.Table.SEVENYNewsTable;

@Service(value="snsbi")
public class SEVENYNewsBizImpl implements SEVENYNewsBiz{

	@Resource(name="snsdi")
	private SEVENYNewsDao snsd;
	
	@Override
	public int insertNews(SEVENYNewsTable snews) {
		return snsd.insertNews(snews); 
	}

	@Override
	public List<SEVENYNewsTable> getNewsByNewsTimeTop10() {
		return snsd.getNewsByNewsTimeTop10();
	}

	@Override
	public List<SEVENYNewsTable> getNewsByUpDate() {
		return snsd.getNewsByUpDate();
	}

	@Override
	public SEVENYNewsTable getNewsByNewsId(int id) {
		return snsd.getNewsByNewsId(id);
	}

}

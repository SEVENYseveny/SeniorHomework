/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.SEVENY.Biz.Impl;

import com.SEVENY.Dao.SEVENYNotesDao;
import com.SEVENY.Dao.Impl.SEVENYNotesDaoImpl;
import com.SEVENY.Table.SEVENYNotesTable;
import com.SEVENY.Biz.SEVENYNotesBiz;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

/**
 
 * @author Lenovo
 */
@Service(value="snbi")
public class SEVENYNotesBizImpl implements SEVENYNotesBiz {

	
	@Resource(name="sndi")
	private SEVENYNotesDao snoted;
	
    @Override
    public int insertNotes(SEVENYNotesTable note) { 
           return snoted.insertNotes(note);
    }

    @Override
    public int deleteNotes(SEVENYNotesTable note) { 
           return snoted.deleteNotes(note); 
    }

    @Override
    public int updateNotes(SEVENYNotesTable note) { 
           return snoted.updateNotes(note); 
    }

    @Override
    public List<SEVENYNotesTable> getNotesByUpUsername(String username) { 
           return snoted.getNotesByUpUsername(username);
    }

    @Override
    public List<SEVENYNotesTable> getNotesByTypeandUpId(int type, int upid) { 
           return snoted.getNotesByTypeandUpId(type,upid); 
    }

    @Override
    public List<SEVENYNotesTable> getNotesByUpDate(int type,int upid) { 
           return snoted.getNotesByUpDate(type,upid); 
    }

    @Override
    public List<SEVENYNotesTable> getNotesByPositiveNum(int type,int upid) { 
           return snoted.getNotesByPositiveNum(type,upid); 
    }

    @Override
    public List<SEVENYNotesTable> getNotesByOkThoughShow() { 
           return snoted.getNotesByOkThoughShow(); 
    }

    @Override
    public List<SEVENYNotesTable> getNotesByNotThoughShow() { 
           return snoted.getNotesByNotThoughShow();  
    }

    @Override
    public List<SEVENYNotesTable> getNotesByThoughShow() { 
           return snoted.getNotesByThoughShow(); 
    }

    @Override
    public List<SEVENYNotesTable> getBookByNotShow() { 
           return snoted.getBookByNotShow();
    }

    @Override
    public List<SEVENYNotesTable> getBookByBookAdmin(String admin) { 
           return snoted.getBookByBookAdmin(admin); 
    }

    @Override
    public List<SEVENYNotesTable> getAllNotesByPositive() { 
           return snoted.getAllNotesByPositive(); 
    }

	@Override
	public SEVENYNotesTable getNotesByNoteId(int noteid) {
		return snoted.getNotesByNoteId(noteid);
	}
    
}

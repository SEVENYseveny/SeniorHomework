
package com.SEVENY.Biz;

import com.SEVENY.Table.SEVENYNotesTable;
import java.util.List;

/**
 * @author Lenovo
 */
public interface SEVENYNotesBiz {
    //增
    int insertNotes(SEVENYNotesTable note);
    
    //删
    int deleteNotes(SEVENYNotesTable note);
    
    //改
    int updateNotes(SEVENYNotesTable note);
    
    //查
    
    //通过笔记的id(自增的)查
    SEVENYNotesTable getNotesByNoteId(int noteid);
    
    //查找某用户所有的评论笔记
    List<SEVENYNotesTable> getNotesByUpUsername(String username);
    
    //查找某书/电影/音乐的评论笔记
    List<SEVENYNotesTable> getNotesByTypeandUpId(int type,int upid);
    
    //通过笔记的上传时间从新到旧
    List<SEVENYNotesTable> getNotesByUpDate(int type,int upid);
    
    //通过笔记的好评个数的多到少
    List<SEVENYNotesTable> getNotesByPositiveNum(int type,int upid);
      
     //查找通过审核并且未放入回收站的笔记
    List<SEVENYNotesTable> getNotesByOkThoughShow();
     //查找未通过审核并且未放入回收站的书
    List<SEVENYNotesTable> getNotesByNotThoughShow();
     //查找还未审核并且未放入回收站的书
    List<SEVENYNotesTable> getNotesByThoughShow();
     //查找放入回收站的书 
    List<SEVENYNotesTable> getBookByNotShow();
    //13.通过书的已经被审核（过/不过），得到指定的管理员审核过的书的list
    List<SEVENYNotesTable> getBookByBookAdmin(String admin);
    
    //查找所有的热评
    List<SEVENYNotesTable> getAllNotesByPositive();
}


package com.SEVENY.CommonlyUsed;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.servlet.http.Part;

import org.springframework.web.multipart.MultipartFile;

/**
 
 * @author Lenovo
 */
public class ChangePicture {
    
    public  void changepic(MultipartFile  filePart,String imgName) throws IOException{
        String path= "D:\\images\\"+ imgName; //指定将文件存到程序中的images目录下  
        System.out.println(path);
        BufferedInputStream bis = new BufferedInputStream(filePart.getInputStream()); //获取上传文件的输入流，用于获取数据流
        File file = new File(path); //创建一个新文件
        file.createNewFile(); //创建文件
        System.out.println(file);
        FileOutputStream fos = new FileOutputStream(file); //使用输出流写入数据到D盘
        int data;
        while ((data = bis.read()) != -1) { //依次读取流中数据，写入到盘中
            fos.write(data);
        } 
    }
}

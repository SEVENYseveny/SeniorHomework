/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.SEVENY.CommonlyUsed;

import java.util.Date;

/**
 
 * @author Lenovo
 */
public class PopularNotesClass {
     
    private Date   noteUpDateTime;   //笔记被上传的日期时间
    private String noteUpUserPic; //上传笔记的用户的头像 
    private String noteUpUserName; //上传笔记的用户名称 
    private int notePositiveNum; //笔记的好评个数
    private String noteTitle;    //笔记的题目
    private String noteContent;   //笔记的内容
    private String titleType;  //书评 /影评 /乐评
    private String titlePic; // 书封面  电影宣传图  音乐专辑图
    private String titletitel;//书名 影片名 音乐明
    private String titleAuthor;//作者 导演 演唱者
    
    private int notetype;  //用来点击评论到详细内容
    private int noteUpId;

    public PopularNotesClass(Date noteUpDateTime, String noteUpUserPic, String noteUpUserName, int notePositiveNum, String noteTitle, String noteContent, String titleType, String titlePic, String titletitel, String titleAuthor, int notetype, int noteUpId) {
        this.noteUpDateTime = noteUpDateTime;
        this.noteUpUserPic = noteUpUserPic;
        this.noteUpUserName = noteUpUserName;
        this.notePositiveNum = notePositiveNum;
        this.noteTitle = noteTitle;
        this.noteContent = noteContent;
        this.titleType = titleType;
        this.titlePic = titlePic;
        this.titletitel = titletitel;
        this.titleAuthor = titleAuthor;
        this.notetype = notetype;
        this.noteUpId = noteUpId;
    }

    
    
    
    public int getNotetype() {
        return notetype;
    }

    public void setNotetype(int notetype) {
        this.notetype = notetype;
    }

    public int getNoteUpId() {
        return noteUpId;
    }

    public void setNoteUpId(int noteUpId) {
        this.noteUpId = noteUpId;
    }
    
    
    
    
    public Date getNoteUpDateTime() {
        return noteUpDateTime;
    }

    public void setNoteUpDateTime(Date noteUpDateTime) {
        this.noteUpDateTime = noteUpDateTime;
    }

    public String getNoteUpUserPic() {
        return noteUpUserPic;
    }

    public void setNoteUpUserPic(String noteUpUserPic) {
        this.noteUpUserPic = noteUpUserPic;
    }

    public String getNoteUpUserName() {
        return noteUpUserName;
    }

    public void setNoteUpUserName(String noteUpUserName) {
        this.noteUpUserName = noteUpUserName;
    }

    public int getNotePositiveNum() {
        return notePositiveNum;
    }

    public void setNotePositiveNum(int notePositiveNum) {
        this.notePositiveNum = notePositiveNum;
    }

    public String getNoteTitle() {
        return noteTitle;
    }

    public void setNoteTitle(String noteTitle) {
        this.noteTitle = noteTitle;
    }

    public String getNoteContent() {
        return noteContent;
    }

    public void setNoteContent(String noteContent) {
        this.noteContent = noteContent;
    }

    public String getTitleType() {
        return titleType;
    }

    public void setTitleType(String titleType) {
        this.titleType = titleType;
    }

    public String getTitlePic() {
        return titlePic;
    }

    public void setTitlePic(String titlePic) {
        this.titlePic = titlePic;
    }

    public String getTitletitel() {
        return titletitel;
    }

    public void setTitletitel(String titletitel) {
        this.titletitel = titletitel;
    }

    public String getTitleAuthor() {
        return titleAuthor;
    }

    public void setTitleAuthor(String titleAuthor) {
        this.titleAuthor = titleAuthor;
    }
    
    
     
}

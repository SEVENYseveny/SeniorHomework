package com.SEVENY.Controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.SEVENY.Biz.SEVENYBookBiz;
import com.SEVENY.Biz.SEVENYMusicBiz;
import com.SEVENY.Biz.SEVENYNotesBiz;
import com.SEVENY.Biz.SEVENYNotesEvaluateBiz;
import com.SEVENY.Biz.SEVENYUserLoginBiz;
import com.SEVENY.Biz.SEVENYVideoBiz;
import com.SEVENY.Table.SEVENYBookTable;
import com.SEVENY.Table.SEVENYMusicTable;
import com.SEVENY.Table.SEVENYNotesEvaluateTable;
import com.SEVENY.Table.SEVENYNotesTable;
import com.SEVENY.Table.SEVENYUserLoginTable;
import com.SEVENY.Table.SEVENYVideoTable;

@Controller
@RequestMapping(value="SEVENY3_0_1_PersonalHomePageMain")
public class SEVENY3_0_1_PersonalHomePageMainController{
	//都通过了审核  并且不再回收站中
    private List<SEVENYBookTable> okbooklist;
    private List<SEVENYVideoTable> okvideolist;
    private List<SEVENYMusicTable> okmusiclist;
    
    //还未审核
    private List<SEVENYBookTable> booklist;
    private List<SEVENYVideoTable> videolist;
    private List<SEVENYMusicTable> musiclist;
    
    //审核未通过
     private List<SEVENYBookTable> nobooklist;
    private List<SEVENYVideoTable> novideolist;
    private List<SEVENYMusicTable> nomusiclist;
    
    //回收站
    private List<SEVENYBookTable> noshowbooklist;
    private List<SEVENYVideoTable> noshowvideolist;
    private List<SEVENYMusicTable> noshowmusiclist;
    
    
    @Resource(name="sbbi")
	private SEVENYBookBiz sbsi;
	
	@Resource(name="smbi")
	private SEVENYMusicBiz smsi;
	
	@Resource(name="svbi")
	private SEVENYVideoBiz svsi;
	
	@Resource(name="snbi")
	private SEVENYNotesBiz snsi;
	
	@Resource(name="sulbi")
	private SEVENYUserLoginBiz suls;
	
	@Resource(name="snebi")
	private SEVENYNotesEvaluateBiz snesi;
	
	@Resource(name="sult")
    private SEVENYUserLoginTable user;
	 

	@Resource(name="sbt")
	private SEVENYBookTable sbook;
	
	@Resource(name="smt")
	private SEVENYMusicTable smusic;
	
	@Resource(name="svt")
	private SEVENYVideoTable svideo;
	
     @RequestMapping(value="show")
     private String show(HttpSession session,Model model)
     {
    	 user =(SEVENYUserLoginTable)session.getAttribute("LoginUser");
    
         okbooklist = sbsi.getBookByUpUsername(user.getUserName());
         okvideolist = svsi.getVideoByUsername(user.getUserName());
         okmusiclist = smsi.getMusicByUpUsername(user.getUserName());
         
         session.setAttribute("okbooklist", okbooklist);
         session.setAttribute("okvideolist", okvideolist);
         session.setAttribute("okmusiclist", okmusiclist);
         
         //还未审核
         booklist = sbsi.getBookByUsernameThoughShow(user.getUserName());
         videolist = svsi.getVideoByUsernameThoughShow(user.getUserName());
         musiclist = smsi.getMusicByUsernameThoughShow(user.getUserName());
         
         session.setAttribute("booklist", booklist);
         session.setAttribute("videolist", videolist);
         session.setAttribute("musiclist", musiclist);
         
         //未通过
         nobooklist = sbsi.getBookByNotThoughShowByUsername(user.getUserName());
         novideolist = svsi.getVideoByNotThrouthOkShowByUsername(user.getUserName());
         nomusiclist = smsi.getMusicByNotThroughOkShowByUsername(user.getUserName());
         
         session.setAttribute("nobooklist", nobooklist);
         session.setAttribute("novideolist", novideolist);
         session.setAttribute("nomusiclist", nomusiclist);
         
         //回收站
         noshowbooklist = sbsi.getBookByNotShowUsername(user.getUserName());
         noshowvideolist = svsi.getVideoByNotShow(user.getUserName());
         noshowmusiclist = smsi.getMusicByNotShow(user.getUserName());
    	 
         session.setAttribute("noshowbooklist", noshowbooklist);
         session.setAttribute("noshowvideolist", noshowvideolist);
         session.setAttribute("noshowmusiclist", noshowmusiclist);
         
    	 model.addAttribute("cho",1);
    	 return "SEVENY3.0.0_PersonalHomepageMain";
     }
     
     
	
	@RequestMapping(value="Up")
	public String Up()
	{
		return "SEVENY3.0.1_PersonalHomepageUp";
//		return "NewFile1";
	}
	
	@RequestMapping(value="joinShow1")
	public String joinShow1(HttpSession session,@RequestParam(value="sbookid") int sbookid)
    { 
		sbook=sbsi.getBookByBookId(sbookid);
        sbook.setBookShow(1);
        sbsi.update(sbook);
        okbooklist = sbsi.getBookByUpUsername(user.getUserName());
        //回收站更新
        noshowbooklist.remove(sbook);
//        session.setAttribute("okbooklist", okbooklist);
//        session.setAttribute("noshowbooklist", noshowbooklist); 
//   	    return "SEVENY3.0.0_PersonalHomepageMain";

        return "redirect:../SEVENY3_0_1_PersonalHomePageMain/show";
    }
	@RequestMapping(value="delete1")
    public String delete1(HttpSession session,@RequestParam(value="sbookid") int sbookid)
    {
		sbook = sbsi.getBookByBookId(sbookid);
        //还要删除这本书所有的评论和赞
        List<SEVENYNotesTable> li= snsi.getNotesByTypeandUpId(1,sbookid);
        for(SEVENYNotesTable n:li)
        {
            List<SEVENYNotesEvaluateTable> ev=snesi.getAllZanByNoteId(n.getNoteId()); //找出所有的赞删除
            for(SEVENYNotesEvaluateTable e:ev)
            {
                snesi.deleteZan(e);
            }
            snsi.deleteNotes(n);
        }
        sbook=sbsi.getBookByBookId(sbookid);
        sbsi.deleteBook(sbook);
        okbooklist.remove(sbook);
        noshowbooklist.remove(sbook);
        booklist.remove(sbook);
//        session.setAttribute("okbooklist", okbooklist);
//        session.setAttribute("noshowbooklist", noshowbooklist);
//        session.setAttribute("booklist", booklist);
//   	 return "SEVENY3.0.0_PersonalHomepageMain";

        return "redirect:../SEVENY3_0_1_PersonalHomePageMain/show";
    }
	@RequestMapping(value="joinNotShow1")
    public String joinNotShow1(HttpSession session,@RequestParam(value="sbookid") int sbookid)
    {
        System.out.println("joinnotshow1");
        sbook=sbsi.getBookByBookId(sbookid);
        sbook.setBookShow(0);
        sbsi.update(sbook);
        okbooklist.remove(sbook);
        //回收站更新 
        noshowbooklist = sbsi.getBookByNotShowUsername(user.getUserName());
//        session.setAttribute("okbooklist", okbooklist);
//        session.setAttribute("noshowbooklist", noshowbooklist);
//   	 return "SEVENY3.0.0_PersonalHomepageMain";

        return "redirect:../SEVENY3_0_1_PersonalHomePageMain/show";
    }
	@RequestMapping(value="joinNotShow2")
     public String joinNotShow2(HttpSession session,@RequestParam(value="svideoid") int svideoid)
    {
        System.out.println("joinnotshow1");
        svideo=svsi.getVideoByVideoId(svideoid);
        svideo.setVideoShow(0);
        svsi.updateVideo(svideo);
        okvideolist.remove(svideo);
        //回收站更新
        noshowvideolist = svsi.getVideoByNotShow(user.getUserName());
//        session.setAttribute("okvideolist", okvideolist);
//        session.setAttribute("noshowvideolist", noshowvideolist);
//   	 return "SEVENY3.0.0_PersonalHomepageMain";

        return "redirect:../SEVENY3_0_1_PersonalHomePageMain/show";
    }
	@RequestMapping(value="delete2")
    public String delete2(HttpSession session,@RequestParam(value="svideoid") int svideoid)
    {
		svideo = svsi.getVideoByVideoId(svideoid);
        //还要删除这本书所有的评论和赞
        List<SEVENYNotesTable> li= snsi.getNotesByTypeandUpId(1,svideoid);
        for(SEVENYNotesTable n:li)
        {
            List<SEVENYNotesEvaluateTable> ev=snesi.getAllZanByNoteId(n.getNoteId()); //找出所有的赞删除
            for(SEVENYNotesEvaluateTable e:ev)
            {
                snesi.deleteZan(e);
            }
            snsi.deleteNotes(n);
        }
        svideo = svsi.getVideoByVideoId(svideoid);
        svsi.deleteVideo(svideo);
        okvideolist.remove(svideo);
        noshowvideolist.remove(svideo);
        videolist.remove(svideo);
//        session.setAttribute("okvideolist", okvideolist);
//        session.setAttribute("noshowvideolist", noshowvideolist);
//        session.setAttribute("videolist", booklist);
//   	 return "SEVENY3.0.0_PersonalHomepageMain";
        return "redirect:../SEVENY3_0_1_PersonalHomePageMain/show";
    }
	@RequestMapping(value="joinShow2")
    public String joinShow2(HttpSession session,@RequestParam(value="svideoid") int svideoid)
    {
        System.out.println("joinnotshow1");
        svideo=svsi.getVideoByVideoId(svideoid);
        svideo.setVideoShow(1);
        svsi.updateVideo(svideo);
        okvideolist = svsi.getVideoByUsername(user.getUserName());
        //回收站更新
        noshowvideolist.remove(svideo);
//        session.setAttribute("okvideolist", okvideolist);
//        session.setAttribute("noshowvideolist", noshowvideolist);
//   	 return "SEVENY3.0.0_PersonalHomepageMain";
        return "redirect:../SEVENY3_0_1_PersonalHomePageMain/show";
    } 
	@RequestMapping(value="joinNotShow3")
     public String joinNotShow3(HttpSession session,@RequestParam(value="smusicid") int smusicid)
    {
        System.out.println("joinnotshow1");
        smusic = smsi.getMusicByMusicId(smusicid);
        smusic.setMusicShow(0);
        smsi.updateMusic(smusic); 
        okmusiclist.remove(smusic);
        //回收站更新
        noshowmusiclist = smsi.getMusicByNotShow(user.getUserName());
//        session.setAttribute("okmusiclist", okmusiclist);
//        session.setAttribute("noshowmusiclist", noshowmusiclist);
//   	 return "SEVENY3.0.0_PersonalHomepageMain";
        return "redirect:../SEVENY3_0_1_PersonalHomePageMain/show";
        
    }
	@RequestMapping(value="delete3")
    public String delete3(HttpSession session,@RequestParam(value="smusicid") int smusicid)
    {
		smusic=smsi.getMusicByMusicId(smusicid);
         //还要删除这本书所有的评论和赞
        List<SEVENYNotesTable> li= snsi.getNotesByTypeandUpId(1,smusicid);
        for(SEVENYNotesTable n:li)
        {
            List<SEVENYNotesEvaluateTable> ev=snesi.getAllZanByNoteId(n.getNoteId()); //找出所有的赞删除
            for(SEVENYNotesEvaluateTable e:ev)
            {
                snesi.deleteZan(e);
            }
            snsi.deleteNotes(n);
        }
        smusic=smsi.getMusicByMusicId(smusicid);
        smsi.deleteMusic(smusic);
        okmusiclist.remove(smusic);
        noshowmusiclist.remove(smusic);
        musiclist.remove(smusic);
//        session.setAttribute("okmusiclist", okmusiclist);
//        session.setAttribute("noshowmusiclist", noshowmusiclist);
//        session.setAttribute("musiclist", musiclist);
//   	 return "SEVENY3.0.0_PersonalHomepageMain";
        return "redirect:../SEVENY3_0_1_PersonalHomePageMain/show";
    }
	@RequestMapping(value="joinShow3")
      public String joinShow3(HttpSession session,@RequestParam(value="smusicid") int smusicid)
    {
        System.out.println("joinnotshow1");
        smusic = smsi.getMusicByMusicId(smusicid);
        smusic.setMusicShow(1);
        smsi.updateMusic(smusic); 
        okmusiclist = smsi.getMusicByUpUsername(user.getUserName());
        //回收站更新
        noshowmusiclist.remove(smusic); 
//        session.setAttribute("okmusiclist", okmusiclist);
//        session.setAttribute("noshowmusiclist", noshowmusiclist);
//   	 return "SEVENY3.0.0_PersonalHomepageMain";
        return "redirect:../SEVENY3_0_1_PersonalHomePageMain/show";
    }
    
	
	
}

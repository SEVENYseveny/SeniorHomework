package com.SEVENY.Controller;
     
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.SEVENY.Biz.SEVENYBookBiz;
import com.SEVENY.CommonlyUsed.PageBean;
import com.SEVENY.Table.SEVENYBookTable;

import java.util.List;

import javax.annotation.Resource;
 
@Controller
@RequestMapping("pageController")
public class PageController {
	@Resource(name="sbbi")
	private SEVENYBookBiz sbooks;
	
    @RequestMapping("page.do")
    /**
     * @param pageNum 当前页,从前台获取。
     */
    public String pageTest(Model model,String pageNum){
        //设置每页显示5条数据
        int pageSize=8;
        int num=Integer.parseInt(pageNum); //当前页
        PageBean<SEVENYBookTable> page = findAll(num, pageSize);
 
        model.addAttribute("page",page);
        return "NewFile";
    }
 
    /**
     * 
     * @param pageNum 当前页
     * @param pageSize 每页显示条数
     * @return
     */
    public PageBean<SEVENYBookTable> findAll(int pageNum, int pageSize){
        //查询总数  
        int totalRecord = (int) sbooks.getBookSize();
        //传递参数 pageNum,pageSzie,totalRecord。
        PageBean pageBean=new PageBean(pageNum,pageSize,totalRecord);
         
        //当前是第pageNum页,要显示的个数为pageSize 
        List<SEVENYBookTable> pageStudent = sbooks.getListByPageNoOrderByUpDate(pageNum, pageSize);
        //将数据传递给PageBean
        pageBean.setList(pageStudent);
        return pageBean;
    }
}
package com.SEVENY.Controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.SEVENY.Biz.SEVENYBookBiz;
import com.SEVENY.Biz.SEVENYMusicBiz;
import com.SEVENY.Biz.SEVENYNewsBiz;
import com.SEVENY.Biz.SEVENYNotesBiz;
import com.SEVENY.Biz.SEVENYVideoBiz;
import com.SEVENY.CommonlyUsed.ChangePicture;
import com.SEVENY.Table.SEVENYBookTable;
import com.SEVENY.Table.SEVENYMusicTable;
import com.SEVENY.Table.SEVENYNewsTable;
import com.SEVENY.Table.SEVENYUserLoginTable;
import com.SEVENY.Table.SEVENYVideoTable;

@Controller
@RequestMapping(value="SEVENY3_0_2_PersonalHomePageUp")
public class SEVENY3_0_2_PersonalHomePageUpController {
     
	@Resource(name="sult")
    private SEVENYUserLoginTable user;

	@Resource(name="sbt")
	private SEVENYBookTable sbook;
	
	@Resource(name="snst")
	private SEVENYNewsTable snew;
	
	@Resource(name="smt")
	private SEVENYMusicTable smusic;
	
	@Resource(name="svt")
	private SEVENYVideoTable svideo;
	
	@Resource(name="sbbi")
	private SEVENYBookBiz sbookser;
	
	@Resource(name="smbi")
	private SEVENYMusicBiz smusics;
	
	@Resource(name="svbi")
	private SEVENYVideoBiz svideos;
	 
	@Resource(name="snsbi")
	private SEVENYNewsBiz snews;
		
	@InitBinder
    protected void initBinder(WebDataBinder binder) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
    }
	
	
	@RequestMapping(value="insertBook")
	public String insertBook(Model model,HttpSession session,
			HttpServletRequest request,
			    @RequestParam(value="bookName",required=false) String bookName,
	            @RequestParam(value="bookAuthor",required=false) String bookAuthor,
			    @RequestParam(value="bookChubanshe",required=false) String bookChubanshe,
			    @RequestParam(value="bookCountry",required=false) String bookCountry,
			    @RequestParam(value="bookPages",required=false) String bookPages,
			    @RequestParam(value="bookBiaoqian",required=false) String bookBiaoqian,
			    @RequestParam(value="filePart",required=false) MultipartFile  filePart,
			    @RequestParam(value="bookContent",required=false) String bookContent
			    ) throws IOException 
    { 
		String imgName ="MoRen.jpg";
        user=(SEVENYUserLoginTable)session.getAttribute("LoginUser");
        String upusername=user.getUserName();
        System.out.println(upusername);
        //将图片存至d盘的images 调用了ChangePicture中的方法  //如果上传了封面图片的话 如果没有，就用默认的图片
        if(null!=filePart)
        {
        	imgName = filePart.getOriginalFilename(); //获取要上传的文件的名称，或者自己起个新的名字
        	if(null==(imgName))
        		imgName ="MoRen.png";
            ChangePicture cp=new ChangePicture(); 
            cp.changepic(filePart, imgName);
        } 
        System.out.println(bookName);
        System.out.println(bookAuthor);
        System.out.println(bookBiaoqian);
        System.out.println(bookCountry);
        System.out.println(imgName);
        System.out.println(bookContent);
        System.out.println(bookChubanshe);
        System.out.println(bookPages);
        //创建BookTable的对象
         //主键hibernate自动会给出  图书上传的日期  时间  用户名 书名 书作者 书出版社 
         //国家 页数 评分 标签 书封面 内容简介 还未审核  审核管理员  审核时间  不在回收站
        Date date = new Date();
        System.out.println(date);
        sbook = new SEVENYBookTable(date,upusername,bookName,bookAuthor,
                bookChubanshe, bookCountry,Integer.parseInt(bookPages),0,bookBiaoqian,imgName,bookContent,1,"z",date,1);
         
        sbookser.insertBook(sbook);
        
        session.setAttribute("ContentType",1);  //查看详情的类型 ，1为图书， 2为电影  3为音乐
        session.setAttribute("ContentDetail", sbook); //要查看的内容 
        return "SEVENY3.2.0_UpContentDetail"; 
         
    }
	
	
	@RequestMapping(value="insertVideo")
	public String insertVideo(HttpSession session,
		    @RequestParam(value="videoName") String videoName,
		    @RequestParam(value="videoauthor") String videoauthor,
		    @RequestParam(value="videoyanyuan") String videoyanyuan,
		    @RequestParam(value="videolanguage") String videolanguage,
		    @RequestParam(value="videotime") String videotime,
		    @RequestParam(value="videotype") String videotype,
		    @RequestParam(value="videoUptime") Date videoUptime,
		    @RequestParam(value="videofilePart",required=false) MultipartFile  videofilePart,
		    @RequestParam(value="videoContent") String videoContent) throws IOException
{ 
	String videoimgName = "MoRen.png";
    user=(SEVENYUserLoginTable)session.getAttribute("LoginUser");
    String upusername=user.getUserName();
    System.out.println(upusername);
    //将图片存至d盘的images 调用了ChangePicture中的方法  //如果上传了封面图片的话 如果没有，就用默认的图片
    if(null!=videofilePart)
    {
        videoimgName = videofilePart.getOriginalFilename(); //获取要上传的文件的名称，或者自己起个新的名字
        ChangePicture cp=new ChangePicture();
        System.out.println(videoimgName);
        cp.changepic(videofilePart, videoimgName);
    } 
    System.out.println(videoUptime);
    System.out.println(new Date());
    System.out.println(user.getUserName());
    System.out.println(videoName);
    System.out.println(videoauthor);
    System.out.println(videoyanyuan);
    System.out.println(videolanguage);
    System.out.println(videotime);
    System.out.println(videoUptime);
    System.out.println(videoimgName);
    System.out.println(videoContent);
    
    svideo=new SEVENYVideoTable(new Date(), user.getUserName(), videoName, videoauthor, videoyanyuan, 
            videolanguage, 0, Integer.parseInt(videotime), videoUptime, videoimgName, videotype, videoContent, 1, "z", new Date(), 1);
    svideos.insertVideo(svideo); 
    session.setAttribute("ContentType",2);  //查看详情的类型 ，1为图书， 2为电影  3为音乐
    session.setAttribute("ContentDetail", svideo); //要查看的内容 
    return "SEVENY3.2.0_UpContentDetail"; 
     
  }
	
	
	@RequestMapping(value="insertMusic")
	public String insertMusic(HttpSession session,
		    @RequestParam(value="musicName") String musicName,
		    @RequestParam(value="musicwordauthor") String musicwordauthor,
		    @RequestParam(value="musicsongwriter") String musicsongwriter,
		    @RequestParam(value="musicsinger") String musicsinger,
		    @RequestParam(value="musicalbum") String musicalbum,
		    @RequestParam(value="musictype") String musictype,
		    @RequestParam(value="musiclink") String musiclink, 
		    @RequestParam(value="musicfilePart",required=false) MultipartFile  musicfilePart,
		    @RequestParam(value="musicContent") String musicContent) throws IOException
{ 
	String musicimgName = "MoRen.png";
    user=(SEVENYUserLoginTable)session.getAttribute("LoginUser");
    String upusername=user.getUserName();
    System.out.println(upusername);
    //将图片存至d盘的images 调用了ChangePicture中的方法  //如果上传了封面图片的话 如果没有，就用默认的图片
    if(null!=musicfilePart)
    {
        musicimgName = musicfilePart.getOriginalFilename(); //获取要上传的文件的名称，或者自己起个新的名字
        ChangePicture cp=new ChangePicture();
        cp.changepic(musicfilePart, musicimgName);
    } 
    System.out.println(musicContent);
    smusic = new SEVENYMusicTable(new Date(),user.getUserName(), musicName, musicwordauthor, musicsongwriter, 
            musicsinger, musicalbum, 0, musiclink, musicimgName, musictype, musicContent, 1, "z", new Date(),1);
    smusics.insertMusic(smusic);
    
    session.setAttribute("ContentType",3);  //查看详情的类型 ，1为图书， 2为电影  3为音乐
    session.setAttribute("ContentDetail", smusic); //要查看的内容
    return "SEVENY3.2.0_UpContentDetail"; 
     
  }
	
	
	@RequestMapping(value="insertnews")
	public String insertNews(HttpSession session,
		    @RequestParam(value="newsName") String newsName,
		    @RequestParam(value="newsauthor") String newsauthor,  
		    @RequestParam(value="newsfilePart",required=false) MultipartFile  newsfilePart,
		    @RequestParam(value="newsContent") String newsContent) throws IOException
{ 
	String newsimgName = "MoRen.png";
    user=(SEVENYUserLoginTable)session.getAttribute("LoginUser");
    String upusername=user.getUserName();
    System.out.println(upusername);
    //将图片存至d盘的images 调用了ChangePicture中的方法  //如果上传了封面图片的话 如果没有，就用默认的图片
    if(null!=newsfilePart)
    {
        newsimgName = newsfilePart.getOriginalFilename(); //获取要上传的文件的名称，或者自己起个新的名字
        ChangePicture cp=new ChangePicture();
        cp.changepic(newsfilePart, newsimgName);
    } 
    System.out.println(newsContent);
    snew = new SEVENYNewsTable(new Date(),newsauthor, newsName, newsContent, 
             newsimgName);
    snews.insertNews(snew); 
    session.setAttribute("newsDetail", snew);   
	
	return "SEVENY5.1.0_NewsContentDetail"; 
     
  }
}

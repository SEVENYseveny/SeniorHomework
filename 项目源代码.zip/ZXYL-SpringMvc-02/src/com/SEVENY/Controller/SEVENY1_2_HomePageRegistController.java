package com.SEVENY.Controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.SEVENY.Table.SEVENYUserLoginTable;
import com.SEVENY.Biz.SEVENYUserLoginBiz;
import com.SEVENY.Biz.Impl.SEVENYUserLoginBizImpl;

@Controller
@RequestMapping(value="SEVENY1_2_HomePageRegist")
public class SEVENY1_2_HomePageRegistController {

	@Resource(name="sulbi")
	private SEVENYUserLoginBiz sulb;
	
	@Resource(name="sult")
	private SEVENYUserLoginTable sult;
	
	@RequestMapping(value="regist") 
	public ModelAndView Regist(Model model,
			  @RequestParam(value="username") String username,
	          @RequestParam(value="password") String password,
	          @RequestParam(value="address") String address,
	          @RequestParam(value="telnumber") String telnumber,
	          @RequestParam(value="yanzhengma") String yanzhengma,
	          HttpSession session,HttpServletRequest request,
	          HttpServletResponse resp){
		
		ModelAndView mav = new ModelAndView();
		
        Date d = new Date();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
        String registdate=df.format(d).toString();
	    System.out.println(df.format(d));
        System.out.println("");
        String head="超级截屏_20181223_093654.png"; 
         
        sult= sulb.getUserByTelNumber(telnumber); 
            if(null!=sult)  //说明此手机号已被注册
            {
            	System.out.println("手机号被注册"); 
            	model.addAttribute("res",1);
            	mav.setViewName("SEVENY1.2_HomePageRegist");
                return mav; //1手机号被注册 

            }else{
            	sult=sulb.getUserByName(username);
                if(null!=sult){    //说明此用户名已经存在
                	System.out.println("用户名已经存在"); 
                	model.addAttribute("res",2);
                	mav.setViewName("SEVENY1.2_HomePageRegist");
                    return mav; //2用户名已经存在 
                }else{
                	
                    sult = new SEVENYUserLoginTable(telnumber,username,password,address,head,registdate);
                    sulb.insert(sult);
                    System.out.println(telnumber+"---"+username+"----"+password);
                    mav.setViewName("SEVENY1.1_HomePageLogin");
                    return mav;
                }
            } 
    }
	
	@RequestMapping(value="login")
	public String ForgetPass()
	{
		return "SEVENY1.1_HomePageLogin";
	}
}

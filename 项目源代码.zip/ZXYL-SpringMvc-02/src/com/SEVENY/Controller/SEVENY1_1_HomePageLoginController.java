package com.SEVENY.Controller;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.SEVENY.Biz.SEVENYUserLoginBiz;
import com.SEVENY.Table.SEVENYUserLoginTable;

@Controller
@RequestMapping(value="SEVENY1_1_HomePageLogin")
public class SEVENY1_1_HomePageLoginController {

	@Resource(name="sulbi")
	private SEVENYUserLoginBiz sulb;
	
	@Resource(name="sult")
	private SEVENYUserLoginTable sult;
	
	
	
	@RequestMapping(value="login")
	public String login(Model model,
			  @RequestParam(value="username") String username,
	          @RequestParam(value="password") String password,
    		          HttpSession session,HttpServletRequest request,
    		          HttpServletResponse resp) {
         
        if("".equals(username)==false&&"".equals(password)==false){ 
        	sult=sulb.getUserByName(username); //通过用户名来查找这个用户
            if(null!=sult&&sult.getUserPassword().equals(password))
            { 
                session.setAttribute("LoginUser",sult);
                session.setAttribute("isLogin","yes");
                return "redirect:../SEVENY2_0_1_FirstPage/FirstNote";
//                return "forward:SEVENY2_0_1_FirstPage/FirstNote";
            }else
            {
            	
            	model.addAttribute("res",1);
            	return "SEVENY1.1_HomePageLogin";
            }
            
        }else{
        	model.addAttribute("res",0);
        	return "SEVENY1.1_HomePageLogin";
        } 
	}
	
	@RequestMapping(value="forgetpass")
	public String ForgetPass()
	{
		return "SEVENY1.3_HomePageUpdatePassword";
	}
	
	@RequestMapping(value="regist")
	public String Regist()
	{
		return "SEVENY1.2_HomePageRegist";
	}
}

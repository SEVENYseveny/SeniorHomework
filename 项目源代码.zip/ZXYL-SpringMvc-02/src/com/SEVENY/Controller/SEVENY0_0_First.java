package com.SEVENY.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
 

@Controller
public class SEVENY0_0_First {
    
//	@RequestMapping(value="/")
//	public String First()
//	{
//		return "SEVENY1.1_HomePageLogin";
//	}
//	
}

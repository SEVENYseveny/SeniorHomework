package com.SEVENY.Controller;

import javax.annotation.Resource; 
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.SEVENY.Biz.SEVENYAdminLoginBiz;
import com.SEVENY.Table.SEVENYAdminLoginTable;

@Controller
@RequestMapping(value="SEVENY4_0_0_AdminLoginPage")
public class SEVENY4_0_0_AdminLoginPageController {

	@Resource(name="salt")
	private SEVENYAdminLoginTable sa;
	
	@Resource(name="salbi")
	private SEVENYAdminLoginBiz salb;
	
	
	@RequestMapping(value="adminLogin")
	public String adminLogin(Model model,
			@RequestParam(value="username") String username,
	          @RequestParam(value="password") String password, 
    		          HttpSession session) {
		 
	       sa=salb.getAdminByName(username);
	       if(null!=sa&&password.equals(sa.getaPassword()))
	       {
	            session.setAttribute("AdminLogin",sa);
	            session.setAttribute("isLogin","yes");
	           return  "redirect:../SEVENY4_1_0_AdminHomepageMain/AdminMain" ;
	       }
	       else
	       {
//	           messaged="用户名或密码错误";
	    	   model.addAttribute("res",1); 
	    	   return "SEVENY4.0.0_AdminLoginPage";
	       } 
	}
	
    @RequestMapping(value="logout")
    public String logout(HttpSession session)
    {
    	session.removeAttribute("isLogin");
    	return "SEVENY4.0.0_AdminLoginPage";
    }
}

package com.SEVENY.Controller;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.SEVENY.Biz.SEVENYNotesBiz;
import com.SEVENY.Table.SEVENYBookTable;
import com.SEVENY.Table.SEVENYMusicTable;
import com.SEVENY.Table.SEVENYNotesTable;
import com.SEVENY.Table.SEVENYUserLoginTable;
import com.SEVENY.Table.SEVENYVideoTable;


@Controller
@RequestMapping(value="SEVENY3_2_1_WriteNotes")
public class SEVENY3_2_1_WriteNotesController {
	
	@Resource(name="sbt")
	private SEVENYBookTable sbook;
	
	@Resource(name="smt")
	private SEVENYMusicTable smusic;
	
	@Resource(name="svt")
	private SEVENYVideoTable svideo;

	@Resource(name="sult")
    private SEVENYUserLoginTable user;
	
	@Resource(name="snt")
	private SEVENYNotesTable snote;
	
	@Resource(name="snbi")
	private SEVENYNotesBiz snotesi;
	
	@RequestMapping(value="returnContent")
	public String returnContent()
	{
		return "SEVENY3.2.0_UpContentDetail";
	} 
	
	@RequestMapping(value="insertNotes")
	public String insertNotes(HttpSession session,
			                  @RequestParam(name="notetitle") String notetitle,
			                  @RequestParam(name="notecontent") String notecontent)
    {
        user=(SEVENYUserLoginTable)session.getAttribute("LoginUser");
        int type=(int)session.getAttribute("ContentType");
        int upid=0;
        if(type==1)   //书
        {
            sbook=(SEVENYBookTable)session.getAttribute("ContentDetail");  
            upid=sbook.getBookId();
        }
        else if(type==2)//电影
        {
            svideo = (SEVENYVideoTable)session.getAttribute("ContentDetail");
            upid=svideo.getVideoId();
        }
        else if(type==3)//音乐
        {
            smusic= (SEVENYMusicTable)session.getAttribute("ContentDetail");
            upid=smusic.getMusicId();
        }                                                                                       //类型  upid  好评 差评 回复个数
         snote=new SEVENYNotesTable( new Date(), user.getUserHeadPic(), user.getUserName(),type,upid, 0, 0, 0, 
                notetitle, notecontent,2, "z", new Date(), 1); 
        snotesi.insertNotes(snote); 
        List<SEVENYNotesTable> snotelist=snotesi.getNotesByPositiveNum(type,upid);
        session.setAttribute("NotesList", snotelist);
        return "SEVENY3.2.0_UpContentDetail";
    }
    
	
}

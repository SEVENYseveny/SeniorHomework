package com.SEVENY.Controller;

import java.io.IOException;

import javax.annotation.Resource;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.SEVENY.Biz.SEVENYUserLoginBiz;
import com.SEVENY.Table.SEVENYUserLoginTable; 
import com.SEVENY.Biz.SEVENYUserLoginBiz;
import com.SEVENY.Biz.Impl.SEVENYUserLoginBizImpl;

@Controller
@RequestMapping(value="SEVENY1_3_HomePageUpdatePassword")
public class SEVENY1_3_HomePageUpdatePasswordController {

	
	@Resource(name="sulbi")
	private SEVENYUserLoginBiz sulb;
	
	@Resource(name="sult")
	private SEVENYUserLoginTable sult;
	
	@RequestMapping(value="judgephone") 
	public ModelAndView JudgePhone(Model model,
	          @RequestParam(value="telnumber") String telnumber, 
	          HttpSession session,HttpServletRequest request,
	          HttpServletResponse resp){ 
        System.out.println(telnumber);
         
        ModelAndView mav = new ModelAndView();
        sult = sulb.getUserByTelNumber(telnumber);
        session.setAttribute("telnumber", telnumber);
        if(null!=sult){ //存在此用户
        	mav.setViewName("SEVENY1.4_HomePageNewPassword");
            return mav; 
        }else{//手机号错误
        	System.out.println("手机号错"); 
        	model.addAttribute("res",2);
        	mav.setViewName("SEVENY1.3_HomePageUpdatePassword");
            return mav;  
        }
        
    }
	
	@RequestMapping(value="updatenewpass")
	public ModelAndView UpdateNewPassword(
			  @RequestParam(value="newpassword") String newpassword, 
	          HttpSession session,HttpServletRequest request,
	          HttpServletResponse resp){  
		String telnumber =(String) session.getAttribute("telnumber");
        System.out.println("您传过来的值为："+telnumber); 
        
        ModelAndView mav = new ModelAndView();
        
        sult = sulb.getUserByTelNumber(telnumber);
        sult.setUserPassword(newpassword); //更换新的密码
        sulb.update(sult);
        mav.setViewName("SEVENY1.1_HomePageLogin");
        return mav;
         
     }
	
	@RequestMapping(value="regist")
	public String Regist()
	{
		return "SEVENY1.2_HomePageRegist";
	}
}

package com.SEVENY.Controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.SEVENY.Biz.SEVENYBookBiz;
import com.SEVENY.Biz.SEVENYMusicBiz;
import com.SEVENY.Biz.SEVENYNotesBiz;
import com.SEVENY.Biz.SEVENYNotesEvaluateBiz;
import com.SEVENY.Biz.SEVENYVideoBiz;
import com.SEVENY.Table.SEVENYBookTable;
import com.SEVENY.Table.SEVENYMusicTable;
import com.SEVENY.Table.SEVENYNotesEvaluateTable;
import com.SEVENY.Table.SEVENYNotesTable;
import com.SEVENY.Table.SEVENYUserLoginTable;
import com.SEVENY.Table.SEVENYVideoTable;

@Controller
@RequestMapping(value="SEVENY3_2_0_UpContentDetail")
public class SEVENY3_2_0_UpContentDetailController {
	
	@Resource(name="sult")
    private SEVENYUserLoginTable user;
	
	@Resource(name="snebi")
	private SEVENYNotesEvaluateBiz snotes;

	@Resource(name="snet")
	private SEVENYNotesEvaluateTable snotet;
	
	@Resource(name="snbi")
	private SEVENYNotesBiz snotesi;
	
	
	@Resource(name="sbbi")
	private SEVENYBookBiz sbooks;
	
	@Resource(name="smbi")
	private SEVENYMusicBiz smusics;
	
	@Resource(name="svbi")
	private SEVENYVideoBiz svideos;
	
	@Resource(name="sbt")
	private SEVENYBookTable sbook;
	
	@Resource(name="smt")
	private SEVENYMusicTable smusic;
	
	@Resource(name="svt")
	private SEVENYVideoTable svideo;
	
	@Resource(name="snt")
	private SEVENYNotesTable note;
	
	@RequestMapping(value="writeNote")
	public String writeNote()
	{
		return "SEVENY3.2.1_WriteNotes";
	}
	
	@RequestMapping(value="okdianzan")
	public String  okdianzan(@RequestParam(name="noteid") int noteid,
			             HttpSession session)
    {  
        user=(SEVENYUserLoginTable)session.getAttribute("LoginUser"); 
        note=snotesi.getNotesByNoteId(noteid);
        int resu=snotes.findZanByIdUserName(noteid,user.getUserName()); 
        if(resu==0){
            snotet=new SEVENYNotesEvaluateTable(user.getUserName(),note.getNoteId());
            snotes.insertZan(snotet); 
            note.setNotePositiveNum(note.getNotePositiveNum()+1);
            snotesi.updateNotes(note);
            findremennote(session);
            return "forward:findremennote";
        }
        return "SEVENY3.2.0_UpContentDetail";
    }
	
	@RequestMapping(value="findremennote")
	public String findremennote(HttpSession session)
    {
        user=(SEVENYUserLoginTable)session.getAttribute("LoginUser");
        int type=(int)session.getAttribute("ContentType");
        int upid=0;
        if(type==1)   //书
        {
            sbook=(SEVENYBookTable)session.getAttribute("ContentDetail");  
            upid=sbook.getBookId();
        }
        else if(type==2)//电影
        {
            svideo = (SEVENYVideoTable)session.getAttribute("ContentDetail");
            upid=svideo.getVideoId();
        }
        else if(type==3)//音乐
        {
            smusic= (SEVENYMusicTable)session.getAttribute("ContentDetail");
            upid=smusic.getMusicId();
        } 
        List<SEVENYNotesTable> snotelist=snotesi.getNotesByPositiveNum(type,upid);
        session.setAttribute("NotesList", snotelist);

        return "SEVENY3.2.0_UpContentDetail";
    } 
	
	@RequestMapping(value="findnewnote")
	public String findnewnote(HttpSession session)
    {
//        user=(SEVENYUserLoginTable)session.getAttribute("LoginUser");
        int type=(int)session.getAttribute("ContentType");
        int upid=0;
        if(type==1)   //书
        {
            sbook=(SEVENYBookTable)session.getAttribute("ContentDetail");  
            upid=sbook.getBookId();
        }
        else if(type==2)//电影
        {
            svideo = (SEVENYVideoTable)session.getAttribute("ContentDetail");
            upid=svideo.getVideoId();
        }
        else if(type==3)//音乐
        {
            smusic= (SEVENYMusicTable)session.getAttribute("ContentDetail");
            upid=smusic.getMusicId();
        } 
        List<SEVENYNotesTable> snotelist=snotesi.getNotesByUpDate(type,upid);
        session.setAttribute("NotesList", snotelist);

        return "SEVENY3.2.0_UpContentDetail";
    }
	
	@RequestMapping(value="updatepingfen")
	public String updatepingfen(HttpSession session,
			      @RequestParam(name="pingfen") int pingfen)
    {  
        System.out.println(pingfen);
        int type =(int) session.getAttribute("ContentType"); //先看类型
        if(type==1)   //书
        {
            sbook=(SEVENYBookTable)session.getAttribute("ContentDetail");  //要拿到这本书的信息来修改评分
            int newscore=0;
            if(sbook.getBookScore()==0){
                newscore=pingfen;
            }    
            else{
                 newscore=(int)(sbook.getBookScore()*0.8+pingfen*0.2);       
            }
            sbook.setBookScore(newscore);
            sbooks.update(sbook);
            session.setAttribute("ContentDetail",sbook);
        }
        else if(type==2)//电影
        {
            svideo = (SEVENYVideoTable)session.getAttribute("ContentDetail");
            int newscore=0;
            if(svideo.getVideoScore()==0){
                newscore=pingfen;
            }    
            else{
                 newscore=(int)(svideo.getVideoScore()*0.8+pingfen*0.2);       
            }
            svideo.setVideoScore(newscore);
            svideos.updateVideo(svideo);
            session.setAttribute("ContentDetail",svideo);
        }
        else if(type==3)//音乐
        {
            smusic= (SEVENYMusicTable)session.getAttribute("ContentDetail");
            int newscore=0;
            if(smusic.getMusicScore()==0){
                newscore=pingfen;
            }    
            else{
                 newscore=(int)(smusic.getMusicScore()*0.8+pingfen*0.2);       
            }
            smusic.setMusicScore(newscore);
            smusics.updateMusic(smusic);
            session.setAttribute("ContentDetail",smusic);
        } 
        
        return "SEVENY3.2.0_UpContentDetail";
        
    }
    
}

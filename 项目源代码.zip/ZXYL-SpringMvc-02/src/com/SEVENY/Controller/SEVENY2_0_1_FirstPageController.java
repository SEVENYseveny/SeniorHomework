package com.SEVENY.Controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.SEVENY.Biz.SEVENYBookBiz;
import com.SEVENY.Biz.SEVENYMusicBiz;
import com.SEVENY.Biz.SEVENYNotesBiz;
import com.SEVENY.Biz.SEVENYVideoBiz;
import com.SEVENY.CommonlyUsed.PopularNotesClass;
import com.SEVENY.Table.SEVENYBookTable;
import com.SEVENY.Table.SEVENYMusicTable;
import com.SEVENY.Table.SEVENYNotesTable;
import com.SEVENY.Table.SEVENYVideoTable;

@Controller
@RequestMapping(value="SEVENY2_0_1_FirstPage")
public class SEVENY2_0_1_FirstPageController {
	

	@Resource(name="sbbi")
	private SEVENYBookBiz sbsi;
	
	@Resource(name="smbi")
	private SEVENYMusicBiz smsi;
	
	@Resource(name="svbi")
	private SEVENYVideoBiz svsi;
	
	@Resource(name="snbi")
	private SEVENYNotesBiz snsi;
	
	@Resource(name="sbt")
	private SEVENYBookTable sbook;
	
	@Resource(name="smt")
	private SEVENYMusicTable smusic;
	
	@Resource(name="svt")
	private SEVENYVideoTable svideo;
	
	@RequestMapping(value="FirstNote")
	public String FirstNote(HttpSession session)
	{
		List<PopularNotesClass> popunotelist=new ArrayList<PopularNotesClass>();

		List<SEVENYNotesTable> snotet = snsi.getAllNotesByPositive();
        for(SEVENYNotesTable s:snotet)
        {
            if(s.getNoteType()==1)
            {String content="";
                if(s.getNoteContent().length()>145)
                {
                    content=s.getNoteContent().substring(0,145);
                    content=content+"....";
                }
                else
                {
                    content=s.getNoteContent()+"....";
                }
                sbook = sbsi.getBookByBookId(s.getNoteUpId());
                PopularNotesClass p=new PopularNotesClass(s.getNoteUpDateTime(), s.getNoteUpUserPic(), s.getNoteUpUserName(), 
                        s.getNotePositiveNum(), s.getNoteTitle(),content,"书评", sbook.getBookPicture(),
                        sbook.getBookName(), sbook.getBookAuthor(), s.getNoteType(),s.getNoteUpId());
                popunotelist.add(p);
            }
            if(s.getNoteType()==2)
            {
                svideo = svsi.getVideoByVideoId(s.getNoteUpId());
                String content="";
                if(s.getNoteContent().length()>145)
                {
                    content=s.getNoteContent().substring(0,145);
                    content=content+"....";
                }
                else
                {
                    content=s.getNoteContent()+"....";
                }
                PopularNotesClass p=new PopularNotesClass(s.getNoteUpDateTime(), s.getNoteUpUserPic(), s.getNoteUpUserName(), 
                        s.getNotePositiveNum(), s.getNoteTitle(), content,"影评", svideo.getVideoPicture(),
                        svideo.getVideoName(),svideo.getVideoAuthor(), s.getNoteType(),s.getNoteUpId());
                popunotelist.add(p);
            }
            if(s.getNoteType()==3)
            {
                smusic = smsi.getMusicByMusicId(s.getNoteUpId());
                String content="";
                if(s.getNoteContent().length()>145)
                {
                    content=s.getNoteContent().substring(0,145);
                    content=content+"....";
                }
                else
                {
                    content=s.getNoteContent()+"....";
                }
                PopularNotesClass p=new PopularNotesClass(s.getNoteUpDateTime(), s.getNoteUpUserPic(), s.getNoteUpUserName(), 
                        s.getNotePositiveNum(), s.getNoteTitle(), content,"乐评", smusic.getMusicPicture(),
                        smusic.getMusicName(), smusic.getMusicSinger(), s.getNoteType(),s.getNoteUpId());
                popunotelist.add(p);
            }
        } 
        for(PopularNotesClass p:popunotelist)
        {
        	System.out.println(p.getTitletitel()+"---"+p.getNoteUpUserName()+"---"+p.getTitleAuthor());
        }
        session.setAttribute("popunotelist", popunotelist);
        return "SEVENY2.0.1_FirstPage";
	}
}

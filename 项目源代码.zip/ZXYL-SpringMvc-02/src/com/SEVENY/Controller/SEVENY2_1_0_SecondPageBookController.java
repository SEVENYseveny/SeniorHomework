package com.SEVENY.Controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping; 

import com.SEVENY.Table.SEVENYBookTable;
import com.SEVENY.Table.SEVENYMusicTable;
import com.SEVENY.Table.SEVENYNewsTable;
import com.SEVENY.Table.SEVENYVideoTable;
import com.SEVENY.Biz.SEVENYBookBiz;
import com.SEVENY.Biz.SEVENYMusicBiz;
import com.SEVENY.Biz.SEVENYNewsBiz;
import com.SEVENY.Biz.SEVENYVideoBiz; 
import com.SEVENY.CommonlyUsed.PageBean;

@Controller
@RequestMapping(value="SEVENY2_1_0_SecondPageBook")
public class SEVENY2_1_0_SecondPageBookController {
	
	@Resource(name="sbbi")
	private SEVENYBookBiz sbooks;
	
	@Resource(name="smbi")
	private SEVENYMusicBiz smusics;
	
	@Resource(name="svbi")
	private SEVENYVideoBiz svideos;
	
	@Resource(name="snsbi")
	private SEVENYNewsBiz snews;
	
	
	//图书的信息
    private List<SEVENYBookTable> bookupdatelist; 
    private List<SEVENYBookTable> bookscorelist; 
   
    
    
    //影片的信息
    private List<SEVENYVideoTable> videostartdatelist; 
    private List<SEVENYVideoTable> videoscorelist; 
   
    
    
    
    //音乐的信息
    private List<SEVENYMusicTable> musicupdatelist; 
    private List<SEVENYMusicTable> musicscorelist; 
    
    private List<SEVENYNewsTable> newsupdatelist;
    
    
    
   
    @RequestMapping(value="FirstBook")
    public String FirstBook(HttpSession session,Model model,String pageNum) {      //一进入这个页面查询图书/电影/音乐的第一页的数据 
        
        //设置每页显示5条数据
        int pageSize=8;
        int Booknum=Integer.parseInt(pageNum); //当前页
        PageBean<SEVENYBookTable> page = findAllBook(Booknum, pageSize);
  
        //获取热门的前十名的书
        bookscorelist = sbooks.getBookByBookScoreTop10();
        session.setAttribute("bookscorelist", bookscorelist);

        model.addAttribute("page",page); 
        
        return "forward:/WEB-INF/jsp/SEVENY2.1.0_SecondPageBook.jsp";
    }
    
    public PageBean<SEVENYBookTable> findAllBook(int pageNum, int pageSize){
        //查询总数  
        int totalRecord = (int) sbooks.getBookSize();
        //传递参数 pageNum,pageSzie,totalRecord。
        PageBean pageBean=new PageBean(pageNum,pageSize,totalRecord);
         
        //当前是第pageNum页,要显示的个数为pageSize 
        bookupdatelist = sbooks.getListByPageNoOrderByUpDate(pageNum, pageSize);
        //将数据传递给PageBean
        pageBean.setList(bookupdatelist);
        return pageBean;
    }
    
    @RequestMapping(value="FirstMusic")
    public String FirstMusic(HttpSession session,Model model,String pageNum) {      //一进入这个页面查询图书/电影/音乐的第一页的数据 
        
    	 //设置每页显示5条数据
        int pageSize=8;
        int Musicnum=Integer.parseInt(pageNum); //当前页
        PageBean<SEVENYMusicTable> page = findAllMusic(Musicnum, pageSize);
  
      //获取热门的前十名的音乐
        musicscorelist = smusics.getMusicByMusicScoreTop10();
        session.setAttribute("musicscorelist", musicscorelist);

        model.addAttribute("page",page); 
        
        return "SEVENY2.1.2_SecondPageMusic";
    	  
    }
    
    
    public PageBean<SEVENYMusicTable> findAllMusic(int pageNum, int pageSize){
        //查询总数  
        int totalRecord = (int) smusics.getMusicSize();
        //传递参数 pageNum,pageSzie,totalRecord。
        PageBean pageBean=new PageBean(pageNum,pageSize,totalRecord);
         
        //当前是第pageNum页,要显示的个数为pageSize 
        musicupdatelist = smusics.getListByPageNoOrderByUpDate(pageNum, pageSize);
        //将数据传递给PageBean
        pageBean.setList(musicupdatelist);
        return pageBean;
    }
    
    @RequestMapping(value="FirstVideo")
    public String FirstVideo(HttpSession session,Model model,String pageNum) {      //一进入这个页面查询图书/电影/音乐的第一页的数据 
        
    	 //设置每页显示5条数据
        int pageSize=8;
        int Videonum=Integer.parseInt(pageNum); //当前页
        PageBean<SEVENYVideoTable> page = findAllVideo(Videonum, pageSize);
  

        //获取热门的前十名的电影
        videoscorelist = svideos.getVideoByVideoScoreTop10();

        session.setAttribute("videoscorelist", videoscorelist);
        
        model.addAttribute("page",page); 
        
        return "SEVENY2.1.1_SecondPageVideo";
         
    }
    
    public PageBean<SEVENYVideoTable> findAllVideo(int pageNum, int pageSize){
        //查询总数  
        int totalRecord = (int) svideos.getVideoSize();
        //传递参数 pageNum,pageSzie,totalRecord。
        PageBean pageBean=new PageBean(pageNum,pageSize,totalRecord);
         
        //当前是第pageNum页,要显示的个数为pageSize 
        videostartdatelist = svideos.getListByPageNoOrderByUpDate(pageNum, pageSize);
        //将数据传递给PageBean
        pageBean.setList(videostartdatelist);
        return pageBean;
    }
    
    
    
   

}

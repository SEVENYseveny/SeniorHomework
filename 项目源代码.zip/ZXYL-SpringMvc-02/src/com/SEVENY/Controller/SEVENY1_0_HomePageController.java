package com.SEVENY.Controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.SEVENY.Biz.SEVENYBookBiz;
import com.SEVENY.Biz.SEVENYMusicBiz;
import com.SEVENY.Biz.SEVENYNewsBiz;
import com.SEVENY.Biz.SEVENYNotesBiz;
import com.SEVENY.Biz.SEVENYUserLoginBiz;
import com.SEVENY.Biz.SEVENYVideoBiz;
import com.SEVENY.Table.SEVENYBookTable;
import com.SEVENY.Table.SEVENYMusicTable;
import com.SEVENY.Table.SEVENYNewsTable;
import com.SEVENY.Table.SEVENYNotesTable;
import com.SEVENY.Table.SEVENYUserLoginTable;
import com.SEVENY.Table.SEVENYVideoTable;

@Controller
public class SEVENY1_0_HomePageController {

	private List<SEVENYBookTable> booklist;
	private List<SEVENYVideoTable> videolist;
	private List<SEVENYMusicTable> musiclist;
	private List<SEVENYNewsTable>  newslist;
	private List<SEVENYNotesTable> snotelist;
	
	@Resource(name="sbbi")
	private SEVENYBookBiz sbooks;
	

	@Resource(name="snsbi")
	private SEVENYNewsBiz snews;
	
	@Resource(name="smbi")
	private SEVENYMusicBiz smusics;
	
	@Resource(name="svbi")
	private SEVENYVideoBiz svideos;
	
	@Resource(name="snbi")
	private SEVENYNotesBiz snotesi;
	
	@Resource(name="sulbi")
	private SEVENYUserLoginBiz suls;
	
	@Resource(name="sult")
    private SEVENYUserLoginTable user;
	
	
	@Resource(name="snst")
    private SEVENYNewsTable snew;
	
	@Resource(name="sbt")
	private SEVENYBookTable sbook;
	
	@Resource(name="smt")
	private SEVENYMusicTable smusic;
	
	@Resource(name="svt")
	private SEVENYVideoTable svideo;
	
	
	@RequestMapping(value="/")
	public String First(HttpSession session)
	{
		newslist=snews.getNewsByNewsTimeTop10();
		session.setAttribute("NewsListByTime", newslist);
		booklist=sbooks.getBookByBookScoreTop10();
        session.setAttribute("BookListByScore", booklist);
        videolist=svideos.getVideoByVideoStartDateTop10();
        session.setAttribute("VideoListByStartDate", videolist);
        musiclist=smusics.getMusicByMusicScoreTop10();
        session.setAttribute("MusicListByScore", musiclist);
		return "SEVENY1.0_HomePage";
	}
	
	
	@RequestMapping(value="login")
	public String login(Model model,
			  @RequestParam(value="username") String username,
	          @RequestParam(value="password") String password,
    		          HttpSession session,HttpServletRequest request,
    		          HttpServletResponse resp) {
         
        if("".equals(username)==false&&"".equals(password)==false){ 
            user=suls.getUserByName(username); //閫氳繃鐢ㄦ埛鍚嶆潵鏌ユ壘杩欎釜鐢ㄦ埛
            if(null!=user&&user.getUserPassword().equals(password))
            { 
                session.setAttribute("LoginUser",user);
                session.setAttribute("isLogin","yes");
                return "forward:SEVENY2_0_1_FirstPage/FirstNote";
            }else
            {
            	
            	model.addAttribute("res",1);
            	return "SEVENY1.1_HomePageLogin";
            }
            
        }else{
        	model.addAttribute("res",0);
        	return "SEVENY1.1_HomePageLogin";
        } 
	}
		
    @RequestMapping(value="logout")
    public String logout(HttpSession session)
    {
    	session.removeAttribute("isLogin");
    	return "SEVENY1.1_HomePageLogin";
    }
	
    @RequestMapping(value="findthenews") 
	public String findthenews(Model model, 
			    @RequestParam(value="id") int id,  
			    HttpSession session,HttpServletRequest request,
			    HttpServletResponse resp){
    	
    	snew=snews.getNewsByNewsId(id);
        session.setAttribute("newsDetail", snew);   
    	
		return "SEVENY5.1.0_NewsContentDetail"; 	
    	
    }
    
    
    
	@RequestMapping(value="findthebvm") 
	public String findthebvm(Model model,
			    @RequestParam(value="type") int type, 
			    @RequestParam(value="id") int id,  
			    HttpSession session,HttpServletRequest request,
			    HttpServletResponse resp){
     
		if(type==1)
	     {
			System.out.println("读书id:   "+id);
	         session.setAttribute("ContentType",1);  //鏌ョ湅璇︽儏鐨勭被鍨� 锛�1涓哄浘涔︼紝 2涓虹數褰�  3涓洪煶涔� 
	         sbook=sbooks.getBookByBookId(id);
	         session.setAttribute("ContentDetail", sbook); //瑕佹煡鐪嬬殑鍐呭
	         System.out.println(sbook.getBookName());
	         snotelist=snotesi.getNotesByPositiveNum(1,id);
	         session.setAttribute("NotesList", snotelist);
	     }
	     else if(type==2)
	     {
	         session.setAttribute("ContentType",2);  //鏌ョ湅璇︽儏鐨勭被鍨� 锛�1涓哄浘涔︼紝 2涓虹數褰�  3涓洪煶涔� 
	         svideo=svideos.getVideoByVideoId(id);
	         session.setAttribute("ContentDetail", svideo); //瑕佹煡鐪嬬殑鍐呭 
	         snotelist=snotesi.getNotesByPositiveNum(2,id);
	         session.setAttribute("NotesList", snotelist);
	     }
	     else if(type==3)
	     {
	         session.setAttribute("ContentType",3);  //鏌ョ湅璇︽儏鐨勭被鍨� 锛�1涓哄浘涔︼紝 2涓虹數褰�  3涓洪煶涔� 
	         SEVENYMusicTable smusic=smusics.getMusicByMusicId(id);  
	         session.setAttribute("ContentDetail", smusic); //瑕佹煡鐪嬬殑鍐呭 
	         snotelist=snotesi.getNotesByPositiveNum(3,id);
	         session.setAttribute("NotesList", snotelist);
	     }
	     
	     return "SEVENY3.2.0_UpContentDetail";
 }
	
	@RequestMapping(value="regist")
	public String Regist()
	{
//		return "SEVENY3.0.1_PersonalHomePageLeft";
		return "SEVENY1.2_HomePageRegist";
	}
	@RequestMapping(value="manynews")
	public String manynews()
    { 
         return "SEVENY5.0.0_SecondPageNews";
    }
	@RequestMapping(value="manybook")
	public String manybook()
    { 
         return "forward:SEVENY2_1_0_SecondPageBook/FirstBook?pageNum=1";
    }
	@RequestMapping(value="manyvideo")
    public String manyvideo()
    {
		return "forward:SEVENY2_1_0_SecondPageBook/FirstVideo?pageNum=1";
    }
      
	@RequestMapping(value="manymusic")
    public String manymusic()
    {
        return "forward:SEVENY2_1_0_SecondPageBook/FirstMusic?pageNum=1";
    }

	@RequestMapping(value="AdminLoginPage")
    public String AdminLoginPage()
    {
        return "SEVENY4.0.0_AdminLoginPage";
    }
	
	@RequestMapping(value="PersonalHomepage")
	public String PersonalHomepage()
	{
		return "forward:SEVENY3_0_1_PersonalHomePageMain/show";
	}

	@RequestMapping(value="AccountManagement")
	public String AccountManagement()
	{
		return "SEVENY3.1.0_AccountManagement";
	}
	
}

package com.SEVENY.Controller;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.SEVENY.Biz.SEVENYBookBiz;
import com.SEVENY.Biz.SEVENYMusicBiz;
import com.SEVENY.Biz.SEVENYNotesBiz;
import com.SEVENY.Biz.SEVENYNotesEvaluateBiz;
import com.SEVENY.Biz.SEVENYUserLoginBiz;
import com.SEVENY.Biz.SEVENYVideoBiz;
import com.SEVENY.Table.SEVENYAdminLoginTable;
import com.SEVENY.Table.SEVENYBookTable;
import com.SEVENY.Table.SEVENYMusicTable;
import com.SEVENY.Table.SEVENYNotesEvaluateTable;
import com.SEVENY.Table.SEVENYNotesTable;
import com.SEVENY.Table.SEVENYUserLoginTable;
import com.SEVENY.Table.SEVENYVideoTable;

@Controller
@RequestMapping(value="SEVENY4_1_0_AdminHomepageMain")
public class SEVENY4_1_0_AdminHomepageMainController {

	//通过了审核 
    private List<SEVENYBookTable> okbooklist;
    private List<SEVENYVideoTable> okvideolist;
    private List<SEVENYMusicTable> okmusiclist;
    
    //还未审核
    private List<SEVENYBookTable> booklist;
    private List<SEVENYVideoTable> videolist;
    private List<SEVENYMusicTable> musiclist;
    
    //审核未通过
    private List<SEVENYBookTable> nobooklist;
    private List<SEVENYVideoTable> novideolist;
    private List<SEVENYMusicTable> nomusiclist;
	
    @Resource(name="sbbi")
	private SEVENYBookBiz sbsi;
	
	@Resource(name="smbi")
	private SEVENYMusicBiz smsi;
	
	@Resource(name="svbi")
	private SEVENYVideoBiz svsi;
	
	@Resource(name="snbi")
	private SEVENYNotesBiz snsi;
	
	@Resource(name="sulbi")
	private SEVENYUserLoginBiz suls;
	
	@Resource(name="snebi")
	private SEVENYNotesEvaluateBiz snesi;
	
	 
	@Resource(name="salt")
	private SEVENYAdminLoginTable admin;

	
	@Resource(name="sbt")
	private SEVENYBookTable sbook;
	
	@Resource(name="smt")
	private SEVENYMusicTable smusic;
	
	@Resource(name="svt")
	private SEVENYVideoTable svideo;
    
	@RequestMapping(value="firstPage")
	public String firstPage()
	{
		return "redirect:../SEVENY2_0_1_FirstPage/FirstNote";
	}
	
	@RequestMapping(value="AdminMain")
	public String AdminMain(HttpSession session)
	{ 
        
		//审核通过的
        okbooklist = sbsi.getBookByOkThoughShow();
        okvideolist = svsi.getVideoByThrouthOkShow();
        okmusiclist = smsi.getMusicByThroughOkShow();
        session.setAttribute("okbooklist", okbooklist);
        session.setAttribute("okvideolist", okvideolist);
        session.setAttribute("okmusiclist", okmusiclist);
        
        //还未审核
        booklist = sbsi.getBookByThoughShow(); 
        videolist = svsi.getVideoByNoOkShow();
        musiclist = smsi.getMusicByNoOkShow();
        session.setAttribute("booklist", booklist);
        session.setAttribute("videolist", videolist);
        session.setAttribute("musiclist", musiclist);
        
        //未通过
        nobooklist = sbsi.getBookByNotThoughShow();
        novideolist = svsi.getVideoByNotThrouthOkShow();
        nomusiclist = smsi.getMusicByNotThroughOkShow();
        session.setAttribute("nobooklist", nobooklist);
        session.setAttribute("novideolist", novideolist);
        session.setAttribute("nomusiclist", nomusiclist);
        return "SEVENY4.1.0_AdminHomepageMain";
	}
	
	@RequestMapping(value="bookokthrough")
	public String bookokthrough(HttpSession session,@RequestParam(name="tbookid") int tbookid)
    {
		admin = (SEVENYAdminLoginTable) session.getAttribute("AdminLogin");
		sbook = sbsi.getBookByBookId(tbookid);
        sbook.setBookExamine(2);
        sbook.setBookExamineDate(new Date());
        sbook.setBookAdmin(admin.getaName());
        sbsi.update(sbook);
        booklist.remove(sbook);
        okbooklist = sbsi.getBookByOkThoughShow();
//        session.setAttribute("booklist", booklist);
//        session.setAttribute("okbooklist", okbooklist);
//        return "SEVENY4.1.0_AdminHomepageMain";
        return "redirect:../SEVENY4_1_0_AdminHomepageMain/AdminMain";
    }
	@RequestMapping(value="videookthrough")
    public String videookthrough(HttpSession session,@RequestParam(name="tvideoid") int tvideoid)
    {
		admin = (SEVENYAdminLoginTable) session.getAttribute("AdminLogin");
		svideo = svsi.getVideoByVideoId(tvideoid);
        svideo.setVideoExamine(2);
        svideo.setVideoExamineDate(new Date());
        svideo.setVideoAdministrators(admin.getaName());
        svsi.updateVideo(svideo);
        videolist.remove(svideo); 
        okvideolist = svsi.getVideoByThrouthOkShow(); 
//        session.setAttribute("videolist", videolist);
//        session.setAttribute("okvideolist", okvideolist);
//        return "SEVENY4.1.0_AdminHomepageMain";
        return "redirect:../SEVENY4_1_0_AdminHomepageMain/AdminMain";
    }
	@RequestMapping(value="musicokthrough")
    public String musicokthrough(HttpSession session,@RequestParam(name="tmusicid") int tmusicid)
    {
		admin = (SEVENYAdminLoginTable) session.getAttribute("AdminLogin");
		smusic = smsi.getMusicByMusicId(tmusicid);
        smusic.setMusicExamine(2);
        smusic.setMusicExamineDate(new Date());
        smusic.setMusicAdmin(admin.getaName());
        smsi.updateMusic(smusic);
        musiclist.remove(smusic);
        okmusiclist = smsi.getMusicByThroughOkShow();
//        session.setAttribute("musiclist", musiclist);
//        session.setAttribute("okmusiclist", okmusiclist);
//        return "SEVENY4.1.0_AdminHomepageMain";
        return "redirect:../SEVENY4_1_0_AdminHomepageMain/AdminMain";
    }
	
	@RequestMapping(value="booknotthrough")
    public String booknotthrough(HttpSession session,@RequestParam(name="tbookid") int tbookid)
    {
		admin = (SEVENYAdminLoginTable) session.getAttribute("AdminLogin");
		sbook = sbsi.getBookByBookId(tbookid);
        sbook.setBookExamine(0);
        sbook.setBookExamineDate(new Date());
        sbook.setBookAdmin(admin.getaName());
        sbsi.update(sbook);
        booklist.remove(sbook);
        nobooklist = sbsi.getBookByNotThoughShow();
//        session.setAttribute("booklist", booklist);
//        session.setAttribute("nobooklist", nobooklist);
//        return "SEVENY4.1.0_AdminHomepageMain";
        return "redirect:../SEVENY4_1_0_AdminHomepageMain/AdminMain";
    }
	@RequestMapping(value="videonotthrough")
    public String videonotthrough(HttpSession session,@RequestParam(name="tvideoid") int tvideoid)
    {
		admin = (SEVENYAdminLoginTable) session.getAttribute("AdminLogin");
		svideo = svsi.getVideoByVideoId(tvideoid);
        svideo.setVideoExamine(0);
        svideo.setVideoExamineDate(new Date());
        svideo.setVideoAdministrators(admin.getaName());
        svsi.updateVideo(svideo);
        videolist.remove(svideo); 
        novideolist = svsi.getVideoByNotThrouthOkShow();
        session.setAttribute("videolist", videolist);
        session.setAttribute("videolist", videolist);
//        return "SEVENY4.1.0_AdminHomepageMain";
        return "redirect:../SEVENY4_1_0_AdminHomepageMain/AdminMain";
    }
	@RequestMapping(value="musicnotthrough")
    public String musicnotthrough(HttpSession session,@RequestParam(name="tmusicid") int tmusicid)
    {
		admin = (SEVENYAdminLoginTable) session.getAttribute("AdminLogin");
        smusic.setMusicExamine(0);
        smusic.setMusicExamineDate(new Date());
        smusic.setMusicAdmin(admin.getaName());
        smsi.updateMusic(smusic);
        musiclist.remove(smusic);
        nomusiclist = smsi.getMusicByNotThroughOkShow();
//        session.setAttribute("musiclist", musiclist);
//        session.setAttribute("nomusiclist", nomusiclist);
//        return "SEVENY4.1.0_AdminHomepageMain";
        return "redirect:../SEVENY4_1_0_AdminHomepageMain/AdminMain";
    }
    
	@RequestMapping(value="delete1")
    public String delete1(HttpSession session,@RequestParam(name="tbookid") int tbookid)
    {
		sbook = sbsi.getBookByBookId(tbookid);
        //还要删除这本书所有的评论和赞
        List<SEVENYNotesTable> li= snsi.getNotesByTypeandUpId(1,sbook.getBookId());
        for(SEVENYNotesTable n:li)
        {
            List<SEVENYNotesEvaluateTable> ev=snesi.getAllZanByNoteId(n.getNoteId()); //找出所有的赞删除
            for(SEVENYNotesEvaluateTable e:ev)
            {
                snesi.deleteZan(e);
            }
            snsi.deleteNotes(n);
        }
        sbsi.deleteBook(sbook);
        okbooklist.remove(sbook);
        nobooklist.remove(sbook);
//        session.setAttribute("okbooklist", okbooklist);
//        session.setAttribute("okbooklist", okbooklist);
//        return "SEVENY4.1.0_AdminHomepageMain";
        return "redirect:../SEVENY4_1_0_AdminHomepageMain/AdminMain";
    }
    
    
	@RequestMapping(value="delete2")
    public String delete2(HttpSession session,@RequestParam(name="tvideoid") int tvideoid)
    {
		svideo = svsi.getVideoByVideoId(tvideoid);
        //还要删除这本书所有的评论和赞
        List<SEVENYNotesTable> li= snsi.getNotesByTypeandUpId(1,svideo.getVideoId());
        for(SEVENYNotesTable n:li)
        {
            List<SEVENYNotesEvaluateTable> ev=snesi.getAllZanByNoteId(n.getNoteId()); //找出所有的赞删除
            for(SEVENYNotesEvaluateTable e:ev)
            {
                snesi.deleteZan(e);
            }
            snsi.deleteNotes(n);
        }
        svsi.deleteVideo(svideo);
        okvideolist.remove(svideo); 
        novideolist.remove(svideo);
//        session.setAttribute("okvideolist", okvideolist);
//        session.setAttribute("novideolist", novideolist);
//        return "SEVENY4.1.0_AdminHomepageMain";
        return "redirect:../SEVENY4_1_0_AdminHomepageMain/AdminMain";
    }
    
    
	@RequestMapping(value="delete3")
    public String delete3(HttpSession session,@RequestParam(name="tmusicid") int tmusicid)
    {
		smusic = smsi.getMusicByMusicId(tmusicid);
         //还要删除这本书所有的评论和赞
        List<SEVENYNotesTable> li= snsi.getNotesByTypeandUpId(1,smusic.getMusicId());
        for(SEVENYNotesTable n:li)
        {
            List<SEVENYNotesEvaluateTable> ev=snesi.getAllZanByNoteId(n.getNoteId()); //找出所有的赞删除
            for(SEVENYNotesEvaluateTable e:ev)
            {
                snesi.deleteZan(e);
            }
            snsi.deleteNotes(n);
        }
        
        smsi.deleteMusic(smusic);
        okmusiclist.remove(smusic); 
        nomusiclist.remove(smusic);
//        session.setAttribute("okmusiclist", okmusiclist);
//        session.setAttribute("nomusiclist", nomusiclist);
//        return "SEVENY4.1.0_AdminHomepageMain";
        return "redirect:../SEVENY4_1_0_AdminHomepageMain/AdminMain";
    }
     
}

package com.SEVENY.Controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.SEVENY.Biz.SEVENYUserLoginBiz;
import com.SEVENY.CommonlyUsed.ChangePicture;
import com.SEVENY.Table.SEVENYUserLoginTable;

@Controller
@RequestMapping(value="SEVENY3_1_0_AccountManagement")
public class SEVENY3_1_0_AccountManagementController {

	@Resource(name="sulbi")
	private SEVENYUserLoginBiz su;

	@Resource(name="sult")
    private SEVENYUserLoginTable suser;
	
	@RequestMapping(value="Updatepwd")
	public String Updatepwd()
	{
		return "SEVENY3.1.1_UpdatePassword";
	}
	
	
	@RequestMapping(value="updateUserDetail")
	public String updateUserDetail(
			HttpSession session,
			@RequestParam(value="filePart",required=false) MultipartFile  filePart) throws IOException
	{
		System.out.println(filePart.getOriginalFilename());
		System.out.println("touxiang");
		suser = (SEVENYUserLoginTable)session.getAttribute("LoginUser");
		if(null!=filePart)
		{
			String imgName = filePart.getOriginalFilename();
			suser.setUserHeadPic(imgName);
			ChangePicture cp=new ChangePicture();
            cp.changepic(filePart, imgName);  
			su.update(suser);
			session.setAttribute("LoginUser", suser);
		}
		
		return "SEVENY3.1.0_AccountManagement";
	}
	
	
	
}

package com.SEVENY.Controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.SEVENY.Biz.SEVENYUserLoginBiz;
import com.SEVENY.Table.SEVENYUserLoginTable;

@Controller
@RequestMapping(value="SEVENY3_1_1_UpdatePassword")
public class SEVENY3_1_1_UpdatePasswordController {

	@Resource(name="sulbi")
	private SEVENYUserLoginBiz su;

	@Resource(name="sult")
    private SEVENYUserLoginTable suser;
	
	@RequestMapping("updatePassword")
	public String updatePassword(HttpSession session,Model model,
			@RequestParam(value="telNumber") String telNumber,
			@RequestParam(value="oldPassword") String oldPassword,
			@RequestParam(value="newPassword") String newPassword,
			@RequestParam(value="newPasswordagain") String newPasswordagain)
    { 
	        suser = su.getUserByTelNumber(telNumber);
	        System.out.println(suser.getUserName());
	        if(suser!=null&&oldPassword.equals(suser.getUserPassword())) //存在此用户 并且旧密码输入的也是正确的
	        {
	            suser.setUserPassword(newPassword);
	            su.update(suser);
	            session.setAttribute("LoginUser",suser); //将会话中的用户的那个属性修改为新的用户的信息
	            return "SEVENY3.1.0_AccountManagement";
	        }
	        else  //手机号输入错误  1
	        {
	        	model.addAttribute("res",1);
	            return "SEVENY3.1.1_UpdatePassword";
	        } 
    }
}

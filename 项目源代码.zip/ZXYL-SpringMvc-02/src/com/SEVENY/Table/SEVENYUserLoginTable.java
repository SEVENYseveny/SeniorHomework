
package com.SEVENY.Table;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.stereotype.Component;

/**
 *SEVENYUserLoginTable类与SEVENYUserLoginTable表对应，存放用户的注册登录信息等
 * @author Lenovo
 */
@Entity
@Component(value="sult")
public class SEVENYUserLoginTable implements Serializable{
  
    @Id  //说明这个属性是主键
    @Column(name="UserTelNumber") //指定该属性映射到表的指定列
    @GeneratedValue(generator="pkUserTelNumber")//指定使用哪个生成器生成主键，指定一个生成器的名字
    @GenericGenerator(name="pkUserTelNumber",strategy="assigned")//与GeneriatedValue对应，指定生成器
    private String userTelNumber;   //用户手机号
    
    @Column(name="UserName")
    private String userName;        //用户名
    
    @Column(name="UserPassword")
    private String userPassword;    //用户密码
    
    @Column(name="UserAddress")  
    private String userAddress;     //用户长居地
    
    @Column(name="UserHeadPic")
    private String userHeadPic;      //用户头像
    
    @Column(name="UserRegistDate")
    private String userRegistDate;   //用户注册日期

    public SEVENYUserLoginTable(){
        
    }
    
    public SEVENYUserLoginTable(String userTelNumber, String userName, String userPassword, String userAddress, String userHeadPic, String userRegistDate) {
        this.userTelNumber = userTelNumber;
        this.userName = userName;
        this.userPassword = userPassword;
        this.userAddress = userAddress;
        this.userHeadPic = userHeadPic;
        this.userRegistDate = userRegistDate;
    }

    
    
    public String getUserTelNumber() {
        return userTelNumber;
    }

    public void setUserTelNumber(String userTelNumber) {
        this.userTelNumber = userTelNumber;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getUserAddress() {
        return userAddress;
    }

    public void setUserAddress(String userAddress) {
        this.userAddress = userAddress;
    }

    public String getUserHeadPic() {
        return userHeadPic;
    }

    public void setUserHeadPic(String userHeadPic) {
        this.userHeadPic = userHeadPic;
    }

    public String getUserRegistDate() {
        return userRegistDate;
    }

    public void setUserRegistDate(String userRegistDate) {
        this.userRegistDate = userRegistDate;
    }
    
    
    
    
}

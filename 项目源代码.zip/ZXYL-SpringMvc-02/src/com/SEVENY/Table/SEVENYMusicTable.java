 
package com.SEVENY.Table;

import java.io.Serializable; 
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.stereotype.Component;

/**
 *与SEVENYBookTable表相对应，存放了上传的图书的信息
 * @author Lenovo
 */
@Entity
@Component(value="smt")
public class SEVENYMusicTable implements Serializable{
    
    @Id
    @GeneratedValue(generator="pkmusicId")
    @GenericGenerator(name="pkmusicId",strategy="increment") //increment是hibernate给出连续的自增的属性id，会先用max得到目前为止最大的id数
    private int musicId; //自增的属性作为id
    
    @Temporal(javax.persistence.TemporalType.TIMESTAMP)
    private Date   musicUpDateTime;   //音乐被上传的日期时间
    private String musicUserName; //上传音乐的用户名称
    private String musicName;     //音乐的名称
    private String musicWordAuthor;   //音乐的词作者
    private String musicSongWriter;    //音乐的曲作者
    private String musicSinger;  //音乐的演唱者
    private String musicAlbum;    //音乐的专辑
    private int    musicScore;    //音乐的评分 
    private String musicLinks;    //音乐的试听链接
    private String musicPicture;  //音乐的图片
    private String musicType;  //音乐的类型 
    private String musicContent;  //歌词内容
    private int    musicExamine;  //音乐的审核情况（1未审核，0审核未通过，2审核通过）
    private String musicAdministrators;    //审核音乐的管理员名称
    @Temporal(javax.persistence.TemporalType.TIMESTAMP)
    private Date musicExamineDate;//音乐被审核的日期
    private int    musicShow;     //音乐是否被移到了回收站（1显示，0被移动到回收站）

    public SEVENYMusicTable(){
        
    }

    public SEVENYMusicTable(Date musicUpDateTime, String musicUserName, String musicName, String musicWordAuthor, String musicSongWriter, String musicSinger, String musicAlbum, int musicScore, String musicLinks, String musicPicture, String musicType, String musicContent, int musicExamine, String musicAdministrators, Date musicExamineDate, int musicShow) {
        this.musicUpDateTime = musicUpDateTime;
        this.musicUserName = musicUserName;
        this.musicName = musicName;
        this.musicWordAuthor = musicWordAuthor;
        this.musicSongWriter = musicSongWriter;
        this.musicSinger = musicSinger;
        this.musicAlbum = musicAlbum;
        this.musicScore = musicScore;
        this.musicLinks = musicLinks;
        this.musicPicture = musicPicture;
        this.musicType = musicType;
        this.musicContent = musicContent;
        this.musicExamine = musicExamine;
        this.musicAdministrators = musicAdministrators;
        this.musicExamineDate = musicExamineDate;
        this.musicShow = musicShow;
    }

    
    
    
    public String getMusicContent() {
        return musicContent;
    }

    public void setMusicContent(String musicContent) {
        this.musicContent = musicContent;
    }

    

    
    public int getMusicId() {
        return musicId;
    }

    public void setMusicId(int musicId) {
        this.musicId = musicId;
    }

    
    public Date getMusicUpDateTime() {
        return musicUpDateTime;
    }

    public void setMusicUpDateTime(Date musicUpDateTime) {
        this.musicUpDateTime = musicUpDateTime;
    }

    public String getMusicUserName() {
        return musicUserName;
    }

    public void setMusicUserName(String musicUserName) {
        this.musicUserName = musicUserName;
    }

    public String getMusicName() {
        return musicName;
    }

    public void setMusicName(String musicName) {
        this.musicName = musicName;
    }

    public String getMusicWordAuthor() {
        return musicWordAuthor;
    }

    public void setMusicWordAuthor(String musicWordAuthor) {
        this.musicWordAuthor = musicWordAuthor;
    }

    public String getMusicSongWriter() {
        return musicSongWriter;
    }

    public void setMusicSongWriter(String musicSongWriter) {
        this.musicSongWriter = musicSongWriter;
    }

    public String getMusicSinger() {
        return musicSinger;
    }

    public void setMusicSinger(String musicSinger) {
        this.musicSinger = musicSinger;
    }

    public String getMusicAlbum() {
        return musicAlbum;
    }

    public void setMusicAlbum(String musicAlbum) {
        this.musicAlbum = musicAlbum;
    }

    public int getMusicScore() {
        return musicScore;
    }

    public void setMusicScore(int musicScore) {
        this.musicScore = musicScore;
    }

    public String getMusicLinks() {
        return musicLinks;
    }

    public void setMusicLinks(String musicLinks) {
        this.musicLinks = musicLinks;
    }

    public String getMusicPicture() {
        return musicPicture;
    }

    public void setMusicPicture(String musicPicture) {
        this.musicPicture = musicPicture;
    }

    public String getMusicType() {
        return musicType;
    }

    public void setMusicType(String musicType) {
        this.musicType = musicType;
    }

    public int getMusicExamine() {
        return musicExamine;
    }

    public void setMusicExamine(int musicExamine) {
        this.musicExamine = musicExamine;
    }

    public String getMusicAdmin() {
        return musicAdministrators;
    }

    public void setMusicAdmin(String musicAdministrators) {
        this.musicAdministrators = musicAdministrators;
    }

    public Date getMusicExamineDate() {
        return musicExamineDate;
    }

    public void setMusicExamineDate(Date musicExamineDate) {
        this.musicExamineDate = musicExamineDate;
    }

    public int getMusicShow() {
        return musicShow;
    }

    public void setMusicShow(int musicShow) {
        this.musicShow = musicShow;
    }

    
    
    
}

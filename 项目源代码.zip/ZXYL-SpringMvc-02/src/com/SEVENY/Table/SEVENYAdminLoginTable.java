package com.SEVENY.Table;
 
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.stereotype.Component;

/**
 *SEVENYUserLoginTable类与SEVENYUserLoginTable表对应，存放用户的注册登录信息等
 * @author Lenovo
 */

@Entity
@Component(value="salt")
public class SEVENYAdminLoginTable implements Serializable{
  
   @Id
    @GeneratedValue(generator = "pkAssigned")
    @GenericGenerator(name = "pkAssigned", strategy = "assigned")
    private String aName;  
    
   private String aPassword;
    

    public SEVENYAdminLoginTable(){
        
    }

    public SEVENYAdminLoginTable(String aName, String aPassword) {
        this.aName = aName;
        this.aPassword = aPassword;
    }

    public String getaName() {
        return aName;
    }

    public void setaName(String aName) {
        this.aName = aName;
    }

    public String getaPassword() {
        return aPassword;
    }

    public void setaPassword(String aPassword) {
        this.aPassword = aPassword;
    }
    
     
    
}

package com.SEVENY.Table;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.stereotype.Component;

@Entity
@Component(value="snst")
public class SEVENYNewsTable {
	@Id
    @Column(name="NewsId")
    @GeneratedValue(generator="pknewsId")
    @GenericGenerator(name="pknewsId",strategy="increment") //increment是hibernate给出连续的自增的属性id，会先用max得到目前为止最大的id数
    private int newsId; //自增的属性作为id
    
    @Column(name="NewsUpDateTime")
    @Temporal(javax.persistence.TemporalType.TIMESTAMP)
    private Date  newsUpDateTime;   //新闻被上传的日期时间
    @Column(name="NewsUserName")
    private String newsUserName; //上传新闻的用户名称
    @Column(name="NewsTitle")
    private String newsTitle;     //新闻的名称 
    @Column(name="NewsContent")
    private String newsContent;  //新闻的内容简介
    @Column(name="NewsPicture")
    private String newsPicture;  //新闻的介绍图片 
    
    public SEVENYNewsTable(){
    	
    }
    
    
	public SEVENYNewsTable(Date newsUpDateTime, String newsUserName, String newsTitle, String newsContent,
			String newsPicture) {
		super();
		this.newsUpDateTime = newsUpDateTime;
		this.newsUserName = newsUserName;
		this.newsTitle = newsTitle;
		this.newsContent = newsContent;
		this.newsPicture = newsPicture;
	}
	public int getNewsId() {
		return newsId;
	}
	public void setNewsId(int newsId) {
		this.newsId = newsId;
	}
	public Date getNewsUpDateTime() {
		return newsUpDateTime;
	}
	public void setNewsUpDateTime(Date newsUpDateTime) {
		this.newsUpDateTime = newsUpDateTime;
	}
	public String getNewsUserName() {
		return newsUserName;
	}
	public void setNewsUserName(String newsUserName) {
		this.newsUserName = newsUserName;
	}
	public String getNewsTitle() {
		return newsTitle;
	}
	public void setNewsTitle(String newsTitle) {
		this.newsTitle = newsTitle;
	}
	public String getNewsContent() {
		return newsContent;
	}
	public void setNewsContent(String newsContent) {
		this.newsContent = newsContent;
	}
	public String getNewsPicture() {
		return newsPicture;
	}
	public void setNewsPicture(String newsPicture) {
		this.newsPicture = newsPicture;
	}

    
}

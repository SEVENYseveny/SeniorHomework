  
package com.SEVENY.Table;

import java.io.Serializable; 
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.stereotype.Component;

/**
 *与SEVENYBookTable表相对应，存放了上传的图书的信息
 * @author Lenovo
 */
@Entity
@Component(value="svt")
public class SEVENYVideoTable implements Serializable{
    
    @Id
    @GeneratedValue(generator="pkvideoId")
    @GenericGenerator(name="pkvideoId",strategy="increment") //increment是hibernate给出连续的自增的属性id，会先用max得到目前为止最大的id数
    private int videoId; //自增的属性作为id
    
    @Temporal(javax.persistence.TemporalType.TIMESTAMP)
    private Date   videoUpDateTime;   //视频被上传的日期时间
    private String videoUserName; //上传视频的用户名称
    private String videoName;     //视频的名称
    private String videoAuthor;   //视频的导演
    private String videoPerformer;    //视频的演员
    private String videoLanguage;  //视频的语言
    private int    videoScore;    //视频的评分
    private int  videoTime;    //视频的时长
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date videoStartDate; //视频的上映日期
    private String videoPicture;  //视频的海报
    private String videoType;  //视频的类型
    private String videoContent; //视频的内容简介
    private int    videoExamine;  //视频的审核情况（1未审核，0审核未通过，2审核通过）
    private String videoAdministrators;    //审核视频的管理员名称
    @Temporal(javax.persistence.TemporalType.TIMESTAMP)
    private Date videoExamineDate;//视频被审核的日期
    private int    videoShow;     //视频是否被移到了回收站（1显示，0被移动到回收站）

    public SEVENYVideoTable(){
        
    }

    public SEVENYVideoTable(Date videoUpDateTime, String videoUserName, String videoName, String videoAuthor, String videoPerformer, String videoLanguage, int videoScore, int videoTime, Date videoStartDate, String videoPicture, String videoType, String videoContent, int videoExamine, String videoAdministrators, Date videoExamineDate, int videoShow) {
        this.videoUpDateTime = videoUpDateTime;
        this.videoUserName = videoUserName;
        this.videoName = videoName;
        this.videoAuthor = videoAuthor;
        this.videoPerformer = videoPerformer;
        this.videoLanguage = videoLanguage;
        this.videoScore = videoScore;
        this.videoTime = videoTime;
        this.videoStartDate = videoStartDate;
        this.videoPicture = videoPicture;
        this.videoType = videoType;
        this.videoContent = videoContent;
        this.videoExamine = videoExamine;
        this.videoAdministrators = videoAdministrators;
        this.videoExamineDate = videoExamineDate;
        this.videoShow = videoShow;
    }

    public int getVideoId() {
        return videoId;
    }

    public void setVideoId(int videoId) {
        this.videoId = videoId;
    }

    public Date getVideoUpDateTime() {
        return videoUpDateTime;
    }

    public void setVideoUpDateTime(Date videoUpDateTime) {
        this.videoUpDateTime = videoUpDateTime;
    }

    public String getVideoUserName() {
        return videoUserName;
    }

    public void setVideoUserName(String videoUserName) {
        this.videoUserName = videoUserName;
    }

    public String getVideoName() {
        return videoName;
    }

    public void setVideoName(String videoName) {
        this.videoName = videoName;
    }

    public String getVideoAuthor() {
        return videoAuthor;
    }

    public void setVideoAuthor(String videoAuthor) {
        this.videoAuthor = videoAuthor;
    }

    public String getVideoPerformer() {
        return videoPerformer;
    }

    public void setVideoPerformer(String videoPerformer) {
        this.videoPerformer = videoPerformer;
    }

    public String getVideoLanguage() {
        return videoLanguage;
    }

    public void setVideoLanguage(String videoLanguage) {
        this.videoLanguage = videoLanguage;
    }

    public int getVideoScore() {
        return videoScore;
    }

    public void setVideoScore(int videoScore) {
        this.videoScore = videoScore;
    }

    public int getVideoTime() {
        return videoTime;
    }

    public void setVideoTime(int videoTime) {
        this.videoTime = videoTime;
    }

    public Date getVideoStartDate() {
        return videoStartDate;
    }

    public void setVideoStartDate(Date videoStartDate) {
        this.videoStartDate = videoStartDate;
    }

    public String getVideoPicture() {
        return videoPicture;
    }

    public void setVideoPicture(String videoPicture) {
        this.videoPicture = videoPicture;
    }

    public String getVideoType() {
        return videoType;
    }

    public void setVideoType(String videoType) {
        this.videoType = videoType;
    }

    public String getVideoContent() {
        return videoContent;
    }

    public void setVideoContent(String videoContent) {
        this.videoContent = videoContent;
    }

    public int getVideoExamine() {
        return videoExamine;
    }

    public void setVideoExamine(int videoExamine) {
        this.videoExamine = videoExamine;
    }

    public String getVideoAdministrators() {
        return videoAdministrators;
    }

    public void setVideoAdministrators(String videoAdministrators) {
        this.videoAdministrators = videoAdministrators;
    }

    public Date getVideoExamineDate() {
        return videoExamineDate;
    }

    public void setVideoExamineDate(Date videoExamineDate) {
        this.videoExamineDate = videoExamineDate;
    }

    public int getVideoShow() {
        return videoShow;
    }

    public void setVideoShow(int videoShow) {
        this.videoShow = videoShow;
    }
    
    

    
}

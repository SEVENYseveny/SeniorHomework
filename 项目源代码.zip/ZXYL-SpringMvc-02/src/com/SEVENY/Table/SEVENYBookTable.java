 
package com.SEVENY.Table;
import java.io.Serializable; 
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.stereotype.Component;

/**
 *与SEVENYBookTable表相对应，存放了上传的图书的信息
 * @author Lenovo
 */
@Entity
@Component(value="sbt")
public class SEVENYBookTable implements Serializable{
    
    @Id
    @Column(name="BookId")
    @GeneratedValue(generator="pkbookId")
    @GenericGenerator(name="pkbookId",strategy="increment") //increment是hibernate给出连续的自增的属性id，会先用max得到目前为止最大的id数
    private int bookId; //自增的属性作为id
    
    @Column(name="BookUpDateTime")
    @Temporal(javax.persistence.TemporalType.TIMESTAMP)
    private Date   bookUpDateTime;   //书被上传的日期时间
    @Column(name="BookUserName")
    private String bookUserName; //上传书的用户名称
    @Column(name="BookName")
    private String bookName;     //书的名称
    @Column(name="BookAuthor") 
    private String bookAuthor;   //书的作者
    @Column(name="BookPress")
    private String bookPress;    //书的出版社
    @Column(name="BookCountry")
    private String bookCountry;  //书的国家
    @Column(name="BookPages")
    private int    bookPages;    //书的页数
    @Column(name="BookScore")
    private int  bookScore;    //书的评分
    @Column(name="BookLabel")
    private String bookLabel;    //书的标签
    @Column(name="BookPicture")
    private String bookPicture;  //书的介绍图片
    @Column(name="BookContent")
    private String bookContent;  //书的内容简介
    @Column(name="BookExamine")
    private int    bookExamine;  //书的审核情况（1未审核，0审核未通过，2审核通过）
    @Column(name="BookAdmin")
    private String bookAdmin;    //审核书的管理员名称
    @Column(name="BookExamineDate")
    @Temporal(javax.persistence.TemporalType.TIMESTAMP)
    private Date bookExamineDate;//书被审核的日期
    @Column(name="BookShow")
    private int    bookShow;     //书是否被移到了回收站（1显示，0被移动到回收站）

    public SEVENYBookTable(){
        
    }

    public SEVENYBookTable(Date bookUpDateTime, String bookUserName, String bookName, String bookAuthor, String bookPress, String bookCountry, int bookPages, int bookScore, String bookLabel, String bookPicture, String bookContent, int bookExamine, String bookAdmin, Date bookExamineDate, int bookShow) {
        this.bookUpDateTime = bookUpDateTime;
        this.bookUserName = bookUserName;
        this.bookName = bookName;
        this.bookAuthor = bookAuthor;
        this.bookPress = bookPress;
        this.bookCountry = bookCountry;
        this.bookPages = bookPages;
        this.bookScore = bookScore;
        this.bookLabel = bookLabel;
        this.bookPicture = bookPicture;
        this.bookContent = bookContent;
        this.bookExamine = bookExamine;
        this.bookAdmin = bookAdmin;
        this.bookExamineDate = bookExamineDate;
        this.bookShow = bookShow;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public Date getBookUpDateTime() {
        return bookUpDateTime;
    }

    public void setBookUpDateTime(Date bookUpDateTime) {
        this.bookUpDateTime = bookUpDateTime;
    }

    public String getBookUserName() {
        return bookUserName;
    }

    public void setBookUserName(String bookUserName) {
        this.bookUserName = bookUserName;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getBookAuthor() {
        return bookAuthor;
    }

    public void setBookAuthor(String bookAuthor) {
        this.bookAuthor = bookAuthor;
    }

    public String getBookPress() {
        return bookPress;
    }

    public void setBookPress(String bookPress) {
        this.bookPress = bookPress;
    }

    public String getBookCountry() {
        return bookCountry;
    }

    public void setBookCountry(String bookCountry) {
        this.bookCountry = bookCountry;
    }

    public int getBookPages() {
        return bookPages;
    }

    public void setBookPages(int bookPages) {
        this.bookPages = bookPages;
    }

    public int getBookScore() {
        return bookScore;
    }

    public void setBookScore(int bookScore) {
        this.bookScore = bookScore;
    }

    public String getBookLabel() {
        return bookLabel;
    }

    public void setBookLabel(String bookLabel) {
        this.bookLabel = bookLabel;
    }

    public String getBookPicture() {
        return bookPicture;
    }

    public void setBookPicture(String bookPicture) {
        this.bookPicture = bookPicture;
    }

    public String getBookContent() {
        return bookContent;
    }

    public void setBookContent(String bookContent) {
        this.bookContent = bookContent;
    }

    public int getBookExamine() {
        return bookExamine;
    }

    public void setBookExamine(int bookExamine) {
        this.bookExamine = bookExamine;
    }

    public String getBookAdmin() {
        return bookAdmin;
    }

    public void setBookAdmin(String bookAdmin) {
        this.bookAdmin = bookAdmin;
    }

    public Date getBookExamineDate() {
        return bookExamineDate;
    }

    public void setBookExamineDate(Date bookExamineDate) {
        this.bookExamineDate = bookExamineDate;
    }

    public int getBookShow() {
        return bookShow;
    }

    public void setBookShow(int bookShow) {
        this.bookShow = bookShow;
    }


}

 
package com.SEVENY.Table;

import java.io.Serializable;
import java.util.Date;
import java.util.logging.Logger;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.stereotype.Component;

/**
 *与SEVENYNotesTable表对应，是对图书/视频/音乐的发表的笔记（字数无限制）
 * @author Lenovo
 */
@Entity
@Component(value="snt")
public class SEVENYNotesTable implements Serializable {
    @Id
    @GeneratedValue(generator="pkNotesId")
    @GenericGenerator(name="pkNotesId",strategy="increment") //increment是hibernate给出连续的自增的属性id，会先用max得到目前为止最大的id数
    private int noteId; //自增的属性作为id
    
    @Temporal(javax.persistence.TemporalType.TIMESTAMP)
    private Date   noteUpDateTime;   //笔记被上传的日期时间
    private String noteUpUserPic; //上传笔记的用户的头像 
    private String noteUpUserName; //上传笔记的用户名称
    private int noteType;        //笔记物的类别（图书1，视频2，音乐3）
    private int noteUpId;        //笔记物的主键id  （所以要确定是图书还是视频，还是音乐，就要通过SRType和SRUpId这两个属性）
    private int notePositiveNum; //笔记的好评个数
    private int noteNegativeNum; //笔记的差评个数
    private int noteReplyNum;    //笔记的回复个数
    private String noteTitle;    //笔记的题目
    private String noteContent;   //笔记的内容
    private int noteExamine;      //是否审核（1还未审核，0审核未过，2通过审核）
    private String noteAdministrators;//审核的管理员
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date noteExamineDate; //审核的时间
    private int noteShow;         //笔记是否被移动到了回收站（1显示，0移到回收站）

    public SEVENYNotesTable() {
    }

    public SEVENYNotesTable(Date noteUpDateTime, String noteUpUserPic, String noteUpUserName, int noteType, int noteUpId, int notePositiveNum, int noteNegativeNum, int noteReplyNum, String noteTitle, String noteContent, int noteExamine, String noteAdministrators, Date noteExamineDate, int noteShow) {
        this.noteUpDateTime = noteUpDateTime;
        this.noteUpUserPic = noteUpUserPic;
        this.noteUpUserName = noteUpUserName;
        this.noteType = noteType;
        this.noteUpId = noteUpId;
        this.notePositiveNum = notePositiveNum;
        this.noteNegativeNum = noteNegativeNum;
        this.noteReplyNum = noteReplyNum;
        this.noteTitle = noteTitle;
        this.noteContent = noteContent;
        this.noteExamine = noteExamine;
        this.noteAdministrators = noteAdministrators;
        this.noteExamineDate = noteExamineDate;
        this.noteShow = noteShow;
    }

     

    public String getNoteTitle() {
        return noteTitle;
    }

    public void setNoteTitle(String noteTitle) {
        this.noteTitle = noteTitle;
    }

    
    public int getNoteId() {
        return noteId;
    }

    public void setNoteId(int noteId) {
        this.noteId = noteId;
    }

    public Date getNoteUpDateTime() {
        return noteUpDateTime;
    }

    public void setNoteUpDateTime(Date noteUpDateTime) {
        this.noteUpDateTime = noteUpDateTime;
    }

    public String getNoteUpUserPic() {
        return noteUpUserPic;
    }

    public void setNoteUpUserPic(String noteUpUserPic) {
        this.noteUpUserPic = noteUpUserPic;
    }

    public String getNoteUpUserName() {
        return noteUpUserName;
    }

    public void setNoteUpUserName(String noteUpUserName) {
        this.noteUpUserName = noteUpUserName;
    }

    public int getNoteType() {
        return noteType;
    }

    public void setNoteType(int noteType) {
        this.noteType = noteType;
    }

    public int getNoteUpId() {
        return noteUpId;
    }

    public void setNoteUpId(int noteUpId) {
        this.noteUpId = noteUpId;
    }

    public int getNotePositiveNum() {
        return notePositiveNum;
    }

    public void setNotePositiveNum(int notePositiveNum) {
        this.notePositiveNum = notePositiveNum;
    }

    public int getNoteNegativeNum() {
        return noteNegativeNum;
    }

    public void setNoteNegativeNum(int noteNegativeNum) {
        this.noteNegativeNum = noteNegativeNum;
    }

    public int getNoteReplyNum() {
        return noteReplyNum;
    }

    public void setNoteReplyNum(int noteReplyNum) {
        this.noteReplyNum = noteReplyNum;
    }

    public String getNoteContent() {
        return noteContent;
    }

    public void setNoteContent(String noteContent) {
        this.noteContent = noteContent;
    }

    public int getNoteExamine() {
        return noteExamine;
    }

    public void setNoteExamine(int noteExamine) {
        this.noteExamine = noteExamine;
    }

    public String getNoteAdministrators() {
        return noteAdministrators;
    }

    public void setNoteAdministrators(String noteAdministrators) {
        this.noteAdministrators = noteAdministrators;
    }

    public Date getNoteExamineDate() {
        return noteExamineDate;
    }

    public void setNoteExamineDate(Date noteExamineDate) {
        this.noteExamineDate = noteExamineDate;
    }

    public int getNoteShow() {
        return noteShow;
    }

    public void setNoteShow(int noteShow) {
        this.noteShow = noteShow;
    }
  
     
}

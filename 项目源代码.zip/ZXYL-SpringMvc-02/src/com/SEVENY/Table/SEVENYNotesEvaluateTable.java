package com.SEVENY.Table;
import java.io.Serializable; 
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id; 
import org.hibernate.annotations.GenericGenerator;
import org.springframework.stereotype.Component;
/**
 *与SEVENYNotesEvaluateTable表对应，是对笔记的好评（收藏）差评的统计
 * @author Lenovo
 */
@Entity
@Component(value="snet")
public class SEVENYNotesEvaluateTable implements Serializable {
    @Id
    @GeneratedValue(generator="pkNEId")
    @GenericGenerator(name="pkNEId",strategy="increment") //increment是hibernate给出连续的自增的属性id，会先用max得到目前为止最大的id数
    private int nEId; //自增的属性作为id 
    private String nEUserName;      //好评的用户名称 
    private int nENoteUpId;        //笔记的主键
    
    private SEVENYNotesEvaluateTable(){
        
    }

    public SEVENYNotesEvaluateTable(String nEUserName, int nENoteUpId) {
        this.nEUserName = nEUserName;
        this.nENoteUpId = nENoteUpId;
    }

    public int getnEId() {
        return nEId;
    }

    public void setnEId(int nEId) {
        this.nEId = nEId;
    }

    public String getnEUserName() {
        return nEUserName;
    }

    public void setnEUserName(String nEUserName) {
        this.nEUserName = nEUserName;
    }

    public int getnENoteUpId() {
        return nENoteUpId;
    }

    public void setnENoteUpId(int nENoteUpId) {
        this.nENoteUpId = nENoteUpId;
    }
    
    
}

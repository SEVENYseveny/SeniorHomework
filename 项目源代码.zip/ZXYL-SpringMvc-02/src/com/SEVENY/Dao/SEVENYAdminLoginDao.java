package com.SEVENY.Dao;
import com.SEVENY.Table.SEVENYAdminLoginTable;

/**
 *定义用户注册信息的有关方法
 * @author Lenovo
 */
public interface SEVENYAdminLoginDao {
     
    //根据用户名查
    SEVENYAdminLoginTable getAdminByName(String name);
     
}

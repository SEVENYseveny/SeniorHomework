package com.SEVENY.Dao;

import java.util.List;

import com.SEVENY.Table.SEVENYNotesEvaluateTable;

public interface SEVENYNotesEvaluateDao {
    int insertZan(SEVENYNotesEvaluateTable snotee);
    
    int findZanByIdUserName(int id,String username);
    
    List<SEVENYNotesEvaluateTable> getAllZanByNoteId(int id);
    
    int deleteZan(SEVENYNotesEvaluateTable snotee);
}

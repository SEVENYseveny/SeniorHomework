
package com.SEVENY.Dao;
import com.SEVENY.Table.SEVENYBookTable;
import java.util.List;

/**
 *定义了关于图书的一些方法，来对SEVENYBookTable进行操作
 * @author Lenovo
 */
public interface SEVENYBookDao {
    
    
    //增
    int insertBook(SEVENYBookTable sbook);
    
    //删
    int deleteBook(SEVENYBookTable sbook);
    //改
    int update(SEVENYBookTable sbook);
    //查
     //1.通过上传书的用户名查找书的list
    List<SEVENYBookTable> getBookByUpUsername(String username);
     //2.通过书的名称来查找书的list
    List<SEVENYBookTable> getBookByUpBookName(String bookname);
     //3.通过书的作者来查找书的list
    List<SEVENYBookTable> getBookByUpBookAuthor(String bookauthor);
     //4.通过书评分的从高到低来存到list中
    List<SEVENYBookTable> getBookByBookScore();
     //5.通过书日期的从新到老来存到list中
    List<SEVENYBookTable> getBookByUpDate();
     //6.查找通过审核并且未放入回收站的书
    List<SEVENYBookTable> getBookByOkThoughShow();
     //7.查找未通过审核并且未放入回收站的书
    List<SEVENYBookTable> getBookByNotThoughShow();
     //8.查找还未审核并且未放入回收站的书
    List<SEVENYBookTable> getBookByThoughShow();
     //9.查找放入回收站的书 
    List<SEVENYBookTable> getBookByNotShow();
     //10.通过出版社找到书的list
    List<SEVENYBookTable> getBookByBookPress(String press);
     //11.通过国家找到书的list 
    List<SEVENYBookTable> getBookByCountry(String country);
     //13.通过书的已经被审核（过/不过），得到指定的管理员审核过的书的list
    List<SEVENYBookTable> getBookByBookAdmin(String admin);
     
    //通过书名称和上传的用户名来查找此书
    SEVENYBookTable getOneBookByUpUsernameAndBookName(String username,String bookname);
    
    List<SEVENYBookTable> getBookByBookScoreTop10();
    
    
    SEVENYBookTable getBookByBookId(int id);
    
    long getBookSize();
    
     List<SEVENYBookTable> getListByPageNoOrderByUpDate(int pageNo, int pageSize);
     
     List<SEVENYBookTable> getBookByUsernameThoughShow(String username);
     
     List<SEVENYBookTable> getBookByNotShowUsername(String username);
     
     List<SEVENYBookTable> getBookByNotThoughShowByUsername(String username);
}

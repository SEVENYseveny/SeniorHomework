
package com.SEVENY.Dao;

import com.SEVENY.Table.SEVENYUserLoginTable;
import java.util.List;

/**
 *定义用户注册信息的有关方法
 * @author Lenovo
 */
public interface SEVENYUserLoginDao {
    
    //增
    int insert(SEVENYUserLoginTable s);
    //改
    int update(SEVENYUserLoginTable s);
    
    //查
    //根据手机号查
    SEVENYUserLoginTable getUserByTelNumber(String tel);
    //根据用户名查
    SEVENYUserLoginTable getUserByName(String name);
    //根据长居地来查同一地区的用户
    List<SEVENYUserLoginTable> getUserByAddress(String add);
}

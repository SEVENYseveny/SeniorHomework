package com.SEVENY.Dao.Impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.SEVENY.Dao.SEVENYNewsDao;
import com.SEVENY.Table.SEVENYNewsTable;
import com.SEVENY.Util.HibernateUtil;


@Repository(value="snsdi")
public class SEVENYNewsDaoImpl implements SEVENYNewsDao{

	@Override
	public int insertNews(SEVENYNewsTable snews) {
		Session session= null;
        int rows=0;
        try{
            session=HibernateUtil.getSession(); //获取一个会话对象和数据库进行交互
            Transaction tran=session.beginTransaction(); //开始一个事务
            session.save(snews);
            tran.commit();//必须提交事务，才能将上述的保存操作完成
            rows=1; 
        }catch(Exception e){
            e.printStackTrace();
        }finally{
             HibernateUtil.close(session); //关闭会话
        }
        return rows;
	}

	@Override
	public List<SEVENYNewsTable> getNewsByNewsTimeTop10() {
		Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYNewsTable  order by newsUpDateTime desc "); 
        query.setFirstResult(0); //设置第一条记录的索引,索引从0开始
        query.setMaxResults(10); //设置检索的记录条数
        List<SEVENYNewsTable> list = query.list();
        HibernateUtil.close(session);
        return list;
	}

	@Override
	public SEVENYNewsTable getNewsByNewsId(int id) {
		Session session = HibernateUtil.getSession();
        SEVENYNewsTable snews = session.get(SEVENYNewsTable.class, id);
        HibernateUtil.close(session);
        return snews;
	}

	@Override
	public List<SEVENYNewsTable> getNewsByUpDate() {
		Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYNewsTable  order by newsUpDateTime desc  "); 
        List<SEVENYNewsTable> list = query.list();
        HibernateUtil.close(session);
        return list;
	}

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.SEVENY.Dao.Impl;

import com.SEVENY.Dao.SEVENYBookDao;
import com.SEVENY.Table.SEVENYBookTable;
import com.SEVENY.Util.HibernateUtil;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository; 

/**
 *
 * @author Lenovo
 */
@Repository(value="sbdi")
public class SEVENYBookDaoImpl implements SEVENYBookDao{

    @Override
    public int insertBook(SEVENYBookTable sbook) {
        Session session= null;
        int rows=0;
        try{
            session=HibernateUtil.getSession(); //获取一个会话对象和数据库进行交互
            Transaction tran=session.beginTransaction(); //开始一个事务
            session.save(sbook);
            tran.commit();//必须提交事务，才能将上述的保存操作完成
            rows=1; 
        }catch(Exception e){
            e.printStackTrace();
        }finally{
             HibernateUtil.close(session); //关闭会话
        }
        return rows;
    }

    @Override
    public int deleteBook(SEVENYBookTable sbook) {
      Session session= null;
        int rows=0;
        try{
            session=HibernateUtil.getSession(); //获取一个会话对象和数据库进行交互
            Transaction tran=session.beginTransaction(); //开始一个事务
            session.delete(sbook);
            tran.commit();//必须提交事务，才能将上述的保存操作完成
            rows=1; 
        }catch(Exception e){
            e.printStackTrace();
        }finally{
             HibernateUtil.close(session); //关闭会话
        }
        return rows;
    }

    @Override
    public int update(SEVENYBookTable sbook) {
        Session session= null;
        int rows=0;
        try{
            session=HibernateUtil.getSession(); //获取一个会话对象和数据库进行交互
            Transaction tran=session.beginTransaction(); //开始一个事务
            session.update(sbook);
            tran.commit();//必须提交事务，才能将上述的保存操作完成
            rows=1; 
        }catch(Exception e){
            e.printStackTrace();
        }finally{
             HibernateUtil.close(session); //关闭会话
        }
        return rows;
    }

    @Override
    public List<SEVENYBookTable> getBookByUpUsername(String username) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYBookTable where bookUserName=:username and bookExamine=2 and bookShow=1 order by bookUpDateTime desc ");
        query.setParameter("username", username); //第二个参数是参数值,是个对象即可,可接受任何类型
        List<SEVENYBookTable> list = query.list();
        HibernateUtil.close(session);
        return list;
    }

    @Override
    public List<SEVENYBookTable> getBookByUpBookName(String bookname) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYBookTable where bookName=:bookname and bookExamine=2 and bookShow=1");
        query.setParameter("bookname", bookname); //第二个参数是参数值,是个对象即可,可接受任何类型
        List<SEVENYBookTable> list = query.list();
        HibernateUtil.close(session);
        return list;
    }

    @Override
    public List<SEVENYBookTable> getBookByUpBookAuthor(String bookauthor) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYBookTable where bookAuthor=:author and bookExamine=2 and bookShow=1");
        query.setParameter("author", bookauthor); //第二个参数是参数值,是个对象即可,可接受任何类型
        List<SEVENYBookTable> list = query.list();
        HibernateUtil.close(session);
        return list;
    }

    @Override
    public List<SEVENYBookTable> getBookByBookScore() {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYBookTable where bookExamine=2 and bookShow=1 order by bookScore desc  "); 
        List<SEVENYBookTable> list = query.list();
        HibernateUtil.close(session);
        return list;
    }

    @Override
    public List<SEVENYBookTable> getBookByBookScoreTop10() {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYBookTable where bookExamine=2 and bookShow=1 order by bookScore desc "); 
        query.setFirstResult(0); //设置第一条记录的索引,索引从0开始
        query.setMaxResults(10); //设置检索的记录条数
        List<SEVENYBookTable> list = query.list();
        HibernateUtil.close(session);
        return list;
    }
    
    @Override
    public List<SEVENYBookTable> getBookByUpDate() {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYBookTable  where bookExamine=2 and bookShow=1 order by bookUpDateTime desc  "); 
        List<SEVENYBookTable> list = query.list();
        HibernateUtil.close(session);
        return list;
    }

    @Override
    public List<SEVENYBookTable> getBookByOkThoughShow() {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYBookTable where bookExamine=2 and bookShow=1"); 
        List<SEVENYBookTable> list = query.list();
        HibernateUtil.close(session);
        return list;
     }

    @Override
    public List<SEVENYBookTable> getBookByNotThoughShow() {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYBookTable where bookExamine=0 and bookShow=1"); 
        List<SEVENYBookTable> list = query.list();
        HibernateUtil.close(session);
        return list;
    }
    
     @Override
    public List<SEVENYBookTable> getBookByNotThoughShowByUsername(String username) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYBookTable where bookExamine=0 and bookShow=1 and bookUserName=:username"); 
        query.setParameter("username", username); 
        List<SEVENYBookTable> list = query.list();
        HibernateUtil.close(session);
        return list;
    }

    @Override
    public List<SEVENYBookTable> getBookByThoughShow() {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYBookTable where bookExamine=1 and bookShow=1"); 
        List<SEVENYBookTable> list = query.list();
        HibernateUtil.close(session);
        return list;
    } 

    @Override
    public List<SEVENYBookTable> getBookByUsernameThoughShow(String username) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYBookTable where bookExamine=1 and bookShow=1 and bookUserName=:username"); 
        query.setParameter("username", username);
        List<SEVENYBookTable> list = query.list();
        HibernateUtil.close(session);
        return list;
    } 
    
    @Override
    public List<SEVENYBookTable> getBookByNotShow() {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYBookTable where  bookShow=0"); 
        List<SEVENYBookTable> list = query.list();
        HibernateUtil.close(session);
        return list;
    }

    @Override
    public List<SEVENYBookTable> getBookByNotShowUsername(String username) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYBookTable where  bookShow=0 and bookUserName=:username"); 
        query.setParameter("username", username);
        List<SEVENYBookTable> list = query.list();
        HibernateUtil.close(session);
        return list;
    }
    
    
    
    @Override
    public List<SEVENYBookTable> getBookByBookPress(String press) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYBookTable where bookPress=:press");
        query.setParameter("press", press); //第二个参数是参数值,是个对象即可,可接受任何类型
        List<SEVENYBookTable> list = query.list();
        HibernateUtil.close(session);
        return list;
    }

    @Override
    public List<SEVENYBookTable> getBookByCountry(String country) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYBookTable where bookCountry=:country");
        query.setParameter("country", country); //第二个参数是参数值,是个对象即可,可接受任何类型
        List<SEVENYBookTable> list = query.list();
        HibernateUtil.close(session);
        return list;
    }

    @Override
    public List<SEVENYBookTable> getBookByBookAdmin(String admin) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYBookTable where bookAdmin=:admin");
        query.setParameter("admin", admin); //第二个参数是参数值,是个对象即可,可接受任何类型
        List<SEVENYBookTable> list = query.list();
        HibernateUtil.close(session);
        return list;
    }

    //通过用户名和书名查找唯一的书
    @Override
    public SEVENYBookTable getOneBookByUpUsernameAndBookName(String username, String bookname) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYBookTable where bookUserName=:username and bookName=:bookname ");
        query.setParameter("username", username); //第二个参数是参数值,是个对象即可,可接受任何类型
        query.setParameter("bookname", bookname);
        SEVENYBookTable  sbook= (SEVENYBookTable)query.uniqueResult();
        HibernateUtil.close(session);
        return sbook; 
    }

    @Override
    public SEVENYBookTable getBookByBookId(int id) {
        Session session = HibernateUtil.getSession();
        SEVENYBookTable sbook = session.get(SEVENYBookTable.class, id);
        HibernateUtil.close(session);
        return sbook;
    }
    
    @Override 
    public long getBookSize()
    {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("select count(*) from SEVENYBookTable  where bookExamine=2 and bookShow=1");  
        long size= (long)query.uniqueResult();
        HibernateUtil.close(session);
        return size;
    }

    @Override
    public List<SEVENYBookTable> getListByPageNoOrderByUpDate(int pageNo, int pageSize) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYBookTable  where bookExamine=2 order by bookUpDateTime desc  "); 
        query.setFirstResult(pageSize * (pageNo - 1)); //设置查询的第一条是指定页面的第一条，可以推算下每页第一条的索引
        query.setMaxResults(pageSize); //设置该页查询的记录数量
        System.out.println(pageNo);
        System.out.println(pageSize);
        List<SEVENYBookTable> list = query.list();
        HibernateUtil.close(session);
        return list;
    }
    
}

package com.SEVENY.Dao.Impl;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.SEVENY.Dao.SEVENYNotesEvaluateDao;
import com.SEVENY.Table.SEVENYNotesEvaluateTable;
import com.SEVENY.Util.HibernateUtil;

@Repository(value="snedi")
public class SEVENYNotesEvaluateDaoImpl implements SEVENYNotesEvaluateDao {

	@Resource(name="snet")
	private SEVENYNotesEvaluateTable snotee;
	
	@Override
    public int insertZan(SEVENYNotesEvaluateTable snotee) {
          Session session= null;
        int rows=0;
        try{
            session=HibernateUtil.getSession(); //获取一个会话对象和数据库进行交互
            Transaction tran=session.beginTransaction(); //开始一个事务
            session.save(snotee);
            tran.commit();//必须提交事务，才能将上述的保存操作完成
            rows=1; 
        }catch(Exception e){
            e.printStackTrace();
        }finally{
             HibernateUtil.close(session); //关闭会话
        }
        return rows;
    }

    @Override
    public int findZanByIdUserName(int id, String username) {
       
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYNotesEvaluateTable where nEUserName=:username and nENoteUpId=:id");
        query.setParameter("username", username); //第二个参数是参数值,是个对象即可,可接受任何类型
        query.setParameter("id", id);
        snotee =(SEVENYNotesEvaluateTable) query.uniqueResult();
                HibernateUtil.close(session);
        if(null!=snotee)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }

    @Override
    public List<SEVENYNotesEvaluateTable> getAllZanByNoteId(int id) {
        
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYNotesEvaluateTable where nENoteUpId=:id");
        query.setParameter("id", id); 
        List<SEVENYNotesEvaluateTable> list=query.list();
        HibernateUtil.close(session);
        return list;
    }

    @Override
    public int deleteZan(SEVENYNotesEvaluateTable snotee) {
          Session session= null;
        int rows=0;
        try{
            session=HibernateUtil.getSession(); //获取一个会话对象和数据库进行交互
            Transaction tran=session.beginTransaction(); //开始一个事务
            session.delete(snotee);
            tran.commit();//必须提交事务，才能将上述的保存操作完成
            rows=1; 
        }catch(Exception e){
            e.printStackTrace();
        }finally{
             HibernateUtil.close(session); //关闭会话
        }
        return rows; 
    }
    
}

package com.SEVENY.Dao.Impl;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.SEVENY.Dao.SEVENYAdminLoginDao;
import com.SEVENY.Table.SEVENYAdminLoginTable;
import com.SEVENY.Util.HibernateUtil;

@Repository(value="saldi")
public class SEVENYAdminLoginDaoImpl implements SEVENYAdminLoginDao {

	@Override
	public SEVENYAdminLoginTable getAdminByName(String name) {
	    
        Session session = HibernateUtil.getSession();
        Transaction tran = session.beginTransaction();
        Query query = session.createQuery("from SEVENYAdminLoginTable where aName=:name");
        query.setParameter("name",name);
        SEVENYAdminLoginTable s = (SEVENYAdminLoginTable)query.uniqueResult();
        tran.commit();
        HibernateUtil.close(session);
        return s;
        
	}

}

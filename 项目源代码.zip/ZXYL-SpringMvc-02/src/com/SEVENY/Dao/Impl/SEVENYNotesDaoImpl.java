/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.SEVENY.Dao.Impl;

import com.SEVENY.Dao.SEVENYNotesDao;
import com.SEVENY.Table.SEVENYNotesTable;
import com.SEVENY.Util.HibernateUtil;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository; 

/**
 
 * @author Lenovo
 */
@Repository(value="sndi")
public class SEVENYNotesDaoImpl implements SEVENYNotesDao{

    @Override
    public int insertNotes(SEVENYNotesTable note) {
        Session session= null;
        int rows=0;
        try{
            session=HibernateUtil.getSession(); //获取一个会话对象和数据库进行交互
            Transaction tran=session.beginTransaction(); //开始一个事务
            session.save(note);
            tran.commit();//必须提交事务，才能将上述的保存操作完成
            rows=1; 
        }catch(Exception e){
            e.printStackTrace();
        }finally{
             HibernateUtil.close(session); //关闭会话
        }
        return rows;
    }

    @Override
    public int deleteNotes(SEVENYNotesTable note) {
          Session session= null;
        int rows=0;
        try{
            session=HibernateUtil.getSession(); //获取一个会话对象和数据库进行交互
            Transaction tran=session.beginTransaction(); //开始一个事务
            session.delete(note);
            tran.commit();//必须提交事务，才能将上述的保存操作完成
            rows=1; 
        }catch(Exception e){
            e.printStackTrace();
        }finally{
             HibernateUtil.close(session); //关闭会话
        }
        return rows; 
    }

    @Override
    public int updateNotes(SEVENYNotesTable note) {
          Session session= null;
        int rows=0;
        try{
            session=HibernateUtil.getSession(); //获取一个会话对象和数据库进行交互
            Transaction tran=session.beginTransaction(); //开始一个事务
            session.update(note);
            tran.commit();//必须提交事务，才能将上述的保存操作完成
            rows=1; 
        }catch(Exception e){
            e.printStackTrace();
        }finally{
             HibernateUtil.close(session); //关闭会话
        }
        return rows; 
    }

    @Override
    public List<SEVENYNotesTable> getNotesByUpUsername(String username) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYNotesTable where noteUserName=:username and noteShow=1");
        query.setParameter("username", username); //第二个参数是参数值,是个对象即可,可接受任何类型
        List<SEVENYNotesTable> list = query.list();
        HibernateUtil.close(session);
        return list;  
    }
    
    @Override
    public SEVENYNotesTable getNotesByNoteId(int noteid) {
        Session session = HibernateUtil.getSession();
        SEVENYNotesTable list = (SEVENYNotesTable)session.get(SEVENYNotesTable.class, noteid);
        HibernateUtil.close(session);
        return list;  
    }

    @Override
    public List<SEVENYNotesTable> getNotesByTypeandUpId(int type, int upid) {
       Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYNotesTable where noteType=:type and noteUpId=:upid and noteShow=1 and  noteExamine=2");
        query.setParameter("type", type); //第二个参数是参数值,是个对象即可,可接受任何类型
        query.setParameter("upid", upid);
        List<SEVENYNotesTable> list = query.list();
        HibernateUtil.close(session);
        return list;     
    }

    @Override
    public List<SEVENYNotesTable> getNotesByUpDate(int type,int upid){
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYNotesTable where noteType=:type and noteUpId=:upid and  noteExamine=2 and noteShow=1 order by noteUpDateTime desc  ");
        query.setParameter("type", type); //第二个参数是参数值,是个对象即可,可接受任何类型
        query.setParameter("upid", upid);
        List<SEVENYNotesTable> list = query.list();
        HibernateUtil.close(session);
        return list;  
    }

    @Override
    public List<SEVENYNotesTable> getNotesByPositiveNum(int type,int upid) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYNotesTable where noteType=:type and noteUpId=:upid and  noteExamine=2  and noteShow=1 order by notePositiveNum desc  "); 
        query.setParameter("type", type); //第二个参数是参数值,是个对象即可,可接受任何类型
        query.setParameter("upid", upid);
        List<SEVENYNotesTable> list = query.list(); 
        HibernateUtil.close(session);
        return list;  
    }

    @Override
    public List<SEVENYNotesTable> getNotesByOkThoughShow() {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYNotesTable where noteExamine=2 and noteShow=1"); 
        List<SEVENYNotesTable> list = query.list();
        HibernateUtil.close(session);
        return list;  
    }

    @Override
    public List<SEVENYNotesTable> getNotesByNotThoughShow() {
         Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYNotesTable where noteExamine=0 and noteShow=1"); 
        List<SEVENYNotesTable> list = query.list();
        HibernateUtil.close(session);
        return list;    
    }

    @Override
    public List<SEVENYNotesTable> getNotesByThoughShow() {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYNotesTable where noteExamine=1 and noteShow=1"); 
        List<SEVENYNotesTable> list = query.list();
        HibernateUtil.close(session);
        return list;     
    }

    @Override
    public List<SEVENYNotesTable> getBookByNotShow() {
       Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYNotesTable where noteShow=0"); 
        List<SEVENYNotesTable> list = query.list();
        HibernateUtil.close(session);
        return list;      
    }

    @Override
    public List<SEVENYNotesTable> getBookByBookAdmin(String admin) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYNotesTable where noteAdministrators=:admin");
        query.setParameter("admin", admin); //第二个参数是参数值,是个对象即可,可接受任何类型
        List<SEVENYNotesTable> list = query.list();
        HibernateUtil.close(session);
        return list;   
    }

    //得到所有的评论的前20个，热度高到低  
    @Override
    public List<SEVENYNotesTable> getAllNotesByPositive() {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYNotesTable where  noteExamine=2 and noteShow=1 order by notePositiveNum desc ");
        query.setFirstResult(0); //设置第一条记录的索引,索引从0开始
        query.setMaxResults(20); //设置检索的记录条数
        List<SEVENYNotesTable> list = query.list();
        return list;  
    }
    
}

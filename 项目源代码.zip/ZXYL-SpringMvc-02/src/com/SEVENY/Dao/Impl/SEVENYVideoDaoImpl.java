/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.SEVENY.Dao.Impl;

import com.SEVENY.Dao.SEVENYVideoDao;
import com.SEVENY.Table.SEVENYVideoTable;
import com.SEVENY.Util.HibernateUtil;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository; 

/**
 
 * @author Lenovo
 */
@Repository(value="svdi")
public class SEVENYVideoDaoImpl implements SEVENYVideoDao{

    @Override
    public int insertVideo(SEVENYVideoTable svideo) {
        Session session= null;
        int rows=0;
        try{
            session=HibernateUtil.getSession(); //获取一个会话对象和数据库进行交互
            Transaction tran=session.beginTransaction(); //开始一个事务
            session.save(svideo);
            tran.commit();//必须提交事务，才能将上述的保存操作完成
            rows=1; 
        }catch(Exception e){
            e.printStackTrace();
        }finally{
             HibernateUtil.close(session); //关闭会话
        }
        return rows;   
    }

    @Override
    public int deleteVideo(SEVENYVideoTable svideo) {
        Session session= null;
        int rows=0;
        try{
            session=HibernateUtil.getSession(); //获取一个会话对象和数据库进行交互
            Transaction tran=session.beginTransaction(); //开始一个事务
            session.delete(svideo);
            tran.commit();//必须提交事务，才能将上述的保存操作完成
            rows=1; 
        }catch(Exception e){
            e.printStackTrace();
        }finally{
             HibernateUtil.close(session); //关闭会话
        }
        return rows;     
    }

    @Override
    public int updateVideo(SEVENYVideoTable svideo) {
         Session session= null;
        int rows=0;
        try{
            session=HibernateUtil.getSession(); //获取一个会话对象和数据库进行交互
            Transaction tran=session.beginTransaction(); //开始一个事务
            session.update(svideo);
            tran.commit();//必须提交事务，才能将上述的保存操作完成
            rows=1; 
        }catch(Exception e){
            e.printStackTrace();
        }finally{
             HibernateUtil.close(session); //关闭会话
        }
        return rows;    
    }

    @Override
    public List<SEVENYVideoTable> getVideoByUsername(String username) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYVideoTable where videoUserName=:username  and videoExamine=2 and videoShow=1 order by  videoUpDateTime desc  ");
        query.setParameter("username", username); //第二个参数是参数值,是个对象即可,可接受任何类型
        List<SEVENYVideoTable> list = query.list();
        return list;    
    }

    @Override
    public List<SEVENYVideoTable> getVideoByVideoName(String videoname) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYVideoTable where videoName=:videoname and videoExamine=2 and videoShow=1");
        query.setParameter("videoname", videoname); //第二个参数是参数值,是个对象即可,可接受任何类型
        List<SEVENYVideoTable> list = query.list();
         HibernateUtil.close(session);
        return list;     
    }

    @Override
    public List<SEVENYVideoTable> getVideoByVideoAuthor(String videoauthor) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYVideoTable where videoAuthor=:videoauthor and videoExamine=2 and videoShow=1");
        query.setParameter("videoauthor", videoauthor); //第二个参数是参数值,是个对象即可,可接受任何类型
        List<SEVENYVideoTable> list = query.list();
         HibernateUtil.close(session);
        return list;       
    }

    @Override
    public List<SEVENYVideoTable> getVideoByVideoScore() {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYVideoTable where videoExamine=2 and videoShow=1 order by videoScore desc "); 
        List<SEVENYVideoTable> list = query.list();
         HibernateUtil.close(session);
        return list;        
    }
    
    @Override
    public List<SEVENYVideoTable> getVideoByVideoScoreTop10() {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYVideoTable where videoExamine=2 and videoShow=1  order by videoScore desc  "); 
        query.setFirstResult(0); //设置第一条记录的索引,索引从0开始
        query.setMaxResults(10); //设置检索的记录条数
        List<SEVENYVideoTable> list = query.list();
         HibernateUtil.close(session);
        return list;        
    }

    @Override
    public List<SEVENYVideoTable> getVideoByUpDate() {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYVideoTable where videoExamine=2 and videoShow=1 order by videoUpDateTime desc "); 
        List<SEVENYVideoTable> list = query.list();
         HibernateUtil.close(session);
        return list;      
    }

    @Override
    public List<SEVENYVideoTable> getVideoByThrouthOkShow() {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYVideoTable where videoExamine=2 and videoShow=1"); 
        List<SEVENYVideoTable> list = query.list();
         HibernateUtil.close(session);
        return list;    
    }

    @Override   //未通过审核
    public List<SEVENYVideoTable> getVideoByNotThrouthOkShow() {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYVideoTable where videoExamine=0 and videoShow=1"); 
        List<SEVENYVideoTable> list = query.list();
         HibernateUtil.close(session);
        return list;        
    }
    
    @Override   //未通过审核
    public List<SEVENYVideoTable> getVideoByNotThrouthOkShowByUsername(String username) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYVideoTable where videoExamine=0 and videoShow=1 and videoUserName=:username "); 
        query.setParameter("username",username); 
        List<SEVENYVideoTable> list = query.list();
         HibernateUtil.close(session);
        return list;        
    }
    
    

    @Override  //还没审核
    public List<SEVENYVideoTable> getVideoByNoOkShow() {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYVideoTable where videoExamine=1 and videoShow=1"); 
        List<SEVENYVideoTable> list = query.list();
         HibernateUtil.close(session);
        return list;        
    }

    @Override   //放入回收站的
    public List<SEVENYVideoTable> getVideoByNotShow(String username) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYVideoTable where videoShow=0  and videoUserName=:username "); 
        query.setParameter("username",username); 
        List<SEVENYVideoTable> list = query.list();
         HibernateUtil.close(session);
        return list;       
    }

    @Override
    public List<SEVENYVideoTable> getVideoByYanYuan(String yyname) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYVideoTable where videoPerformer like=:name and videoExamine=2"); 
        query.setParameter("name", "%"+yyname+"%"); //第二个参数是参数值,是个对象即可,可接受任何类型 
        List<SEVENYVideoTable> list = query.list();
         HibernateUtil.close(session);
        return list;         
    }

    @Override
    public List<SEVENYVideoTable> getVideoByVideoLanguage(String language) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYVideoTable where videoLanguage=:language and videoExamine=2"); 
        query.setParameter("language", language); //第二个参数是参数值,是个对象即可,可接受任何类型 
        List<SEVENYVideoTable> list = query.list();
         HibernateUtil.close(session);
        return list;      
    }

    @Override
    public List<SEVENYVideoTable> getVideoByVideoType(String type) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYVideoTable where videoType=:type and videoExamine=2"); 
        query.setParameter("type", type); //第二个参数是参数值,是个对象即可,可接受任何类型 
        List<SEVENYVideoTable> list = query.list();
         HibernateUtil.close(session);
        return list;           
    }

    @Override
    public List<SEVENYVideoTable> getBookByVideoAdmin(String admin) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYVideoTable where videoAdmin=:admin"); 
        query.setParameter("admin", admin); //第二个参数是参数值,是个对象即可,可接受任何类型 
        List<SEVENYVideoTable> list = query.list();
         HibernateUtil.close(session);
        return list;       
    }

    @Override
    public SEVENYVideoTable getOneVideoByUpUsernameAndVideoName(String username, String videoname) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYVideoTable where videoUserName=:username and videoName=:videoname ");
        query.setParameter("username", username); //第二个参数是参数值,是个对象即可,可接受任何类型
        query.setParameter("videoname", videoname);
        SEVENYVideoTable  svideo= (SEVENYVideoTable)query.uniqueResult();
         HibernateUtil.close(session);
        return svideo;      
    }

    @Override
    public SEVENYVideoTable getVideoByVideoId(int id) {
        Session session = HibernateUtil.getSession();
        SEVENYVideoTable svideo=session.get(SEVENYVideoTable.class, id);
         HibernateUtil.close(session);
        return svideo;
    }
    @Override
    public List<SEVENYVideoTable> getVideoByVideoStartDateTop10()
    {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYVideoTable where videoExamine=2  order by videoStartDate desc  "); 
        query.setFirstResult(0); //设置第一条记录的索引,索引从0开始
        query.setMaxResults(10); //设置检索的记录条数
        List<SEVENYVideoTable> list = query.list();
         HibernateUtil.close(session);
        return list;  
    }

    @Override
    public int getVideoSize() {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("select count(*) from SEVENYVideoTable where videoExamine=2 and videoShow=1");  
        long size=(long)query.uniqueResult();
        HibernateUtil.close(session);
        return (int)size;
    }

    @Override
    public List<SEVENYVideoTable> getListByPageNoOrderByUpDate(int pageNo, int pageSize) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYVideoTable where videoExamine=2 and videoShow=1 order by videoUpDateTime desc "); 
        query.setFirstResult(pageSize * (pageNo - 1)); //设置查询的第一条是指定页面的第一条，可以推算下每页第一条的索引
        query.setMaxResults(pageSize); //设置该页查询的记录数量
        List<SEVENYVideoTable> list = query.list();
        HibernateUtil.close(session);
        return list;    
    }

    @Override
    public List<SEVENYVideoTable> getVideoByUsernameThoughShow(String username) {
Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYVideoTable where videoExamine=1 and videoShow=1 and videoUserName=:username "); 
        query.setParameter("username", username);
        List<SEVENYVideoTable> list = query.list();
        HibernateUtil.close(session);
        return list;  
    }
    
}

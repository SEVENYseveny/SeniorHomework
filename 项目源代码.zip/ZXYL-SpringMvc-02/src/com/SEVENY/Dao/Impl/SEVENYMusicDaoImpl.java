/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.SEVENY.Dao.Impl;

import com.SEVENY.Dao.SEVENYMusicDao;
import com.SEVENY.Table.SEVENYMusicTable;
import com.SEVENY.Util.HibernateUtil;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository; 

/**
 *
 * @author Lenovo
 */
@Repository(value="smdi")
public class SEVENYMusicDaoImpl implements SEVENYMusicDao{

    @Override
    public int insertMusic(SEVENYMusicTable smusic) {
        Session session= null;
        int rows=0;
        try{
            session=HibernateUtil.getSession(); //获取一个会话对象和数据库进行交互
            Transaction tran=session.beginTransaction(); //开始一个事务
            session.save(smusic);
            tran.commit();//必须提交事务，才能将上述的保存操作完成
            rows=1; 
        }catch(Exception e){
            e.printStackTrace();
        }finally{
             HibernateUtil.close(session); //关闭会话
        }
        return rows;       
    }

    @Override
    public int deleteMusic(SEVENYMusicTable smusic) {
         Session session= null;
        int rows=0;
        try{
            session=HibernateUtil.getSession(); //获取一个会话对象和数据库进行交互
            Transaction tran=session.beginTransaction(); //开始一个事务
            session.delete(smusic);
            tran.commit();//必须提交事务，才能将上述的保存操作完成
            rows=1; 
        }catch(Exception e){
            e.printStackTrace();
        }finally{
             HibernateUtil.close(session); //关闭会话
        }
        return rows;   
    }

    @Override
    public int updateMusic(SEVENYMusicTable smusic) {
         Session session= null;
        int rows=0;
        try{
            session=HibernateUtil.getSession(); //获取一个会话对象和数据库进行交互
            Transaction tran=session.beginTransaction(); //开始一个事务
            session.update(smusic);
            tran.commit();//必须提交事务，才能将上述的保存操作完成
            rows=1; 
        }catch(Exception e){
            e.printStackTrace();
        }finally{
             HibernateUtil.close(session); //关闭会话
        }
        return rows;    
    }

    @Override
    public List<SEVENYMusicTable> getMusicByUpUsername(String username) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYMusicTable where musicUserName=:username and  musicExamine=2 and musicShow=1 order by musicUpDateTime desc   ");
        query.setParameter("username", username); //第二个参数是参数值,是个对象即可,可接受任何类型
        List<SEVENYMusicTable> list = query.list();
        HibernateUtil.close(session);
        return list;        
    }

    @Override
    public List<SEVENYMusicTable> getMusicByMusicName(String musicname) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYMusicTable where musicName=:musicname and musicExamine=2 and musicShow=1");
        query.setParameter("musicname", musicname); //第二个参数是参数值,是个对象即可,可接受任何类型
        List<SEVENYMusicTable> list = query.list();
        HibernateUtil.close(session);
        return list;      
    }

    @Override
    public List<SEVENYMusicTable> getMusicByMusicSinger(String singer) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYMusicTable where musicSinger=:singer and musicExamine=2 and musicShow=1");
        query.setParameter("singer", singer); //第二个参数是参数值,是个对象即可,可接受任何类型
        List<SEVENYMusicTable> list = query.list();
        HibernateUtil.close(session);
        return list;      
    }

    @Override
    public List<SEVENYMusicTable> getMusicByMusicScore() {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYMusicTable where  musicExamine=2 and musicShow=1 order by musicScore desc ");
        List<SEVENYMusicTable> list = query.list();
        HibernateUtil.close(session);
        return list;      
    }
    
     @Override
    public List<SEVENYMusicTable> getMusicByMusicScoreTop10() {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYMusicTable where  musicExamine=2 and musicShow=1 order by musicScore desc  ");
        query.setFirstResult(0); //设置第一条记录的索引,索引从0开始
        query.setMaxResults(10); //设置检索的记录条数
        List<SEVENYMusicTable> list = query.list();
        HibernateUtil.close(session);
        return list;      
    }

    @Override
    public List<SEVENYMusicTable> getMusicByMusicDate() {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYMusicTable where  musicExamine=2 and musicShow=1 order by musicUpDateTime desc  ");
        List<SEVENYMusicTable> list = query.list();
        HibernateUtil.close(session);
        return list;    
    }

    @Override
    public List<SEVENYMusicTable> getMusicByThroughOkShow() {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYMusicTable where musicExamine=2 and musicShow=1"); 
        List<SEVENYMusicTable> list = query.list();
        HibernateUtil.close(session);
        return list;     
    }

    @Override
    public List<SEVENYMusicTable> getMusicByNotThroughOkShowByUsername(String username) {
         Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYMusicTable where musicExamine=0 and musicShow=1 and musicUserName=:username"); 
        query.setParameter("username", username);
        List<SEVENYMusicTable> list = query.list();
        HibernateUtil.close(session);
        return list;      
    }
    
    @Override
    public List<SEVENYMusicTable> getMusicByNotThroughOkShow() {
         Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYMusicTable where musicExamine=0 and musicShow=1"); 
        List<SEVENYMusicTable> list = query.list();
        HibernateUtil.close(session);
        return list;      
    }

    @Override
    public List<SEVENYMusicTable> getMusicByNoOkShow() {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYMusicTable where musicExamine=1 and musicShow=1"); 
        List<SEVENYMusicTable> list = query.list();
        HibernateUtil.close(session);
        return list;       
    }

    @Override
    public List<SEVENYMusicTable> getMusicByNotShow(String username) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYMusicTable where  musicShow=0  and  musicUserName=:username"); 
        query.setParameter("username", username);
        List<SEVENYMusicTable> list = query.list();
        HibernateUtil.close(session);
        return list;       
    }

    @Override
    public List<SEVENYMusicTable> getMusicByMusicWord(String musicword) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYMusicTable where musicWordAuthor=:musicword and  musicExamine=2");
        query.setParameter("musicword", musicword); //第二个参数是参数值,是个对象即可,可接受任何类型
        List<SEVENYMusicTable> list = query.list();
        HibernateUtil.close(session);
        return list;       
    }

    @Override
    public List<SEVENYMusicTable> getMusicByMusicSong(String song) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYMusicTable where musicSongWriter=:song and musicExamine=2");
        query.setParameter("song", song); //第二个参数是参数值,是个对象即可,可接受任何类型
        List<SEVENYMusicTable> list = query.list();
        HibernateUtil.close(session);
        return list;       
    }

    @Override
    public List<SEVENYMusicTable> getMusicByMusicType(String musictype) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYMusicTable where musicType=:musictype and  musicExamine=2");
        query.setParameter("musictype", musictype); //第二个参数是参数值,是个对象即可,可接受任何类型
        List<SEVENYMusicTable> list = query.list();
        HibernateUtil.close(session);
        return list;     
    }

    @Override
    public List<SEVENYMusicTable> getMusicByMusicAdmin(String admin) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYMusicTable where musicAdmin=:admin");
        query.setParameter("admin", admin); //第二个参数是参数值,是个对象即可,可接受任何类型
        List<SEVENYMusicTable> list = query.list();
        HibernateUtil.close(session);
        return list;        
    }

    @Override
    public List<SEVENYMusicTable> getMusicByMusicAlbum(String album) {
         Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYMusicTable where musicAlbum=:album and musicExamine=2");
        query.setParameter("album", album); //第二个参数是参数值,是个对象即可,可接受任何类型
        List<SEVENYMusicTable> list = query.list();
        HibernateUtil.close(session);
        return list;     
    }

    @Override
    public SEVENYMusicTable getOneMusicByUpUsernameAndMusicName(String username, String musicname) {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYMusicTable where musicUserName=:username and musicName=:musicname");
        query.setParameter("username", username); //第二个参数是参数值,是个对象即可,可接受任何类型
        query.setParameter("musicname", musicname);
        SEVENYMusicTable smusic = (SEVENYMusicTable)query.uniqueResult();
        HibernateUtil.close(session);
        return smusic;      
    }

    @Override
    public SEVENYMusicTable getMusicByMusicId(int id) {
        Session session = HibernateUtil.getSession();
        SEVENYMusicTable svideo=session.get(SEVENYMusicTable.class, id);
        HibernateUtil.close(session);
        return svideo;
    }

    @Override
    public int getMusicSize() {
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("select count(*) from SEVENYMusicTable where musicExamine=2 and musicShow=1"); 
        long size=(long)query.uniqueResult();     
        HibernateUtil.close(session);
        return (int)size;
    }

    @Override
    public List<SEVENYMusicTable> getListByPageNoOrderByUpDate(int pageNo, int pageSize) {
       Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYMusicTable where  musicExamine=2 order by musicUpDateTime desc  ");
        query.setFirstResult(pageSize * (pageNo - 1)); //设置查询的第一条是指定页面的第一条，可以推算下每页第一条的索引
        query.setMaxResults(pageSize); //设置该页查询的记录数量
        List<SEVENYMusicTable> list = query.list();
         HibernateUtil.close(session);
        return list;    
    }

    @Override
    public List<SEVENYMusicTable> getMusicByUsernameThoughShow(String username) {
      
        Session session = HibernateUtil.getSession();
        Query query=session.createQuery("from SEVENYMusicTable where musicExamine=1 and musicShow=1 and musicUserName=:username "); 
        query.setParameter("username", username);
        List<SEVENYMusicTable> list = query.list();
        HibernateUtil.close(session);
        return list;  

    }
    
}

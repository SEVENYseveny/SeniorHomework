 
package com.SEVENY.Dao.Impl;
import com.SEVENY.Dao.SEVENYUserLoginDao;
import com.SEVENY.Table.SEVENYUserLoginTable;
import com.SEVENY.Util.HibernateUtil;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository; 

/**
 *SEVENYUserLoginDao接口的实现类，给出SEVENYUserLoginTable表的操作代码，用户的注册信息
 * @author Lenovo
 */
@Repository(value="suldi")
public class SEVENYUserLoginDaoImpl implements SEVENYUserLoginDao {

    @Override
    public int insert(SEVENYUserLoginTable s) {

        Session session = null;
        int rows=0;
        try{
            session=HibernateUtil.getSession(); //获取一个会话对象和数据库进行交互
            Transaction tran=session.beginTransaction(); //开始一个事务
            session.save(s);//保存一位用户的信息，就是插入用户信息到数据库
            tran.commit();//必须提交事务，才能将上述的保存操作完成
            rows=1; 
        }catch(Exception e){
            e.printStackTrace();
        }finally{
             HibernateUtil.close(session); //关闭会话
        }
        return rows;
    }

    @Override
    public int update(SEVENYUserLoginTable s) {
       Session session = null;
       int rows=0;
       try{
           session = HibernateUtil.getSession();
           Transaction tran=session.beginTransaction();
           session.update(s);     
           tran.commit();
           rows=1;
       }catch(Exception e){
           e.printStackTrace();
       }finally{
           HibernateUtil.close(session);
       }
       return rows;
    }

    @Override
    public SEVENYUserLoginTable getUserByTelNumber(String tel) { 
        Session session = HibernateUtil.getSession();
        Transaction tran=session.beginTransaction(); 
        //使用get（）方法通过主键得到整个对象
        SEVENYUserLoginTable s=(SEVENYUserLoginTable)session.get(SEVENYUserLoginTable.class, tel);
        tran.commit();
        HibernateUtil.close(session);
        return s;
    }

    @Override
    public SEVENYUserLoginTable getUserByName(String name) { 
        Session session = HibernateUtil.getSession();
        Transaction tran = session.beginTransaction();
        Query query = session.createQuery("from SEVENYUserLoginTable where userName=:name");
        query.setParameter("name",name);
        SEVENYUserLoginTable s = (SEVENYUserLoginTable)query.uniqueResult();
        tran.commit();
        HibernateUtil.close(session);
        return s;
    }

    @Override
    public List<SEVENYUserLoginTable> getUserByAddress(String add) {

        Session session = HibernateUtil.getSession();
        Transaction tran = session.beginTransaction();
        Query query = session.createQuery("from SEVENYUserLoginTable where userAddress=:ua");
        query.setParameter("ua",add);
        List<SEVENYUserLoginTable> list =  query.list();
        tran.commit();
        HibernateUtil.close(session);
        return list;
    }
    
}

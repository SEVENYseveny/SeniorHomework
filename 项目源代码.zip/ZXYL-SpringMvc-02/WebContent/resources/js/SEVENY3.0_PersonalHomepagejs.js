function focus_bookname(txt)
{
    document.getElementById("s1").innerHTML = "例：疯狂的Android讲义";
    document.getElementById("s1").style.color="gray";
}
function blur_bookname(txt)
{
    if(txt.value.length===0)
    {
        document.getElementById("s1").innerHTML = "请输入书籍的名称";
        document.getElementById("s1").style.color="red";
    }
    else
    {
        document.getElementById("s1").innerHTML = "";
        document.getElementById("s1").style.color="grey";
    }
    
}
function focus_bookauthor(txt)
{
    document.getElementById("s2").innerHTML = "例：李刚";
    document.getElementById("s2").style.color="gray";
}
function blur_bookauthor(txt)
{
    if(txt.value.length===0)
    {
        document.getElementById("s2").innerHTML = "请输入书籍的作者";
        document.getElementById("s2").style.color="red";
    }
    else
    {
        document.getElementById("s2").innerHTML = "";
        document.getElementById("s2").style.color="grey";
    }
    
}
function focus_bookchubanshe(txt)
{
    document.getElementById("s3").innerHTML = "例：电子工业出版社";
    document.getElementById("s3").style.color="gray";
}
function blur_bookchubanshe(txt)
{
    if(txt.value.length===0)
    {
        document.getElementById("s3").innerHTML = "请输入书籍的出版社";
        document.getElementById("s3").style.color="red";
    }
    else
    {
        document.getElementById("s3").innerHTML = "";
        document.getElementById("s3").style.color="grey";
    }
    
}
function focus_bookcountry(txt)
{
    document.getElementById("s4").innerHTML = "例：中国";
    document.getElementById("s4").style.color="gray";
}
function blur_bookcountry(txt)
{
    if(txt.value.length===0)
    {
        document.getElementById("s4").innerHTML = "请输入书籍所属国家";
        document.getElementById("s4").style.color="red";
    }
    else
    {
        document.getElementById("s4").innerHTML = "";
        document.getElementById("s4").style.color="grey";
    }
    
}
function focus_booknumber(txt)
{
    document.getElementById("s5").innerHTML = "例：765";
    document.getElementById("s5").style.color="gray";
}
function blur_booknumber(txt)
{
    var reg = new RegExp("^[0-9]{1,30}$");
    if(txt.value.length===0)
    {
        document.getElementById("s5").innerHTML = "请输入书籍的页数";
        document.getElementById("s5").style.color="red";
    } 
    else if(reg.test(txt.value))
    {
        document.getElementById("s5").innerHTML = "";
        document.getElementById("s5").style.color="grey";
    } 
    else
    {
        document.getElementById("s5").innerHTML = "输入正确的数字";
        document.getElementById("s5").style.color="red";
    }
    
}
function focus_bookbiaoqian(txt)
{
    document.getElementById("s6").innerHTML = "例：编程";
    document.getElementById("s6").style.color="gray";
}
function blur_bookbiaoqian(txt)
{
    if(txt.value.length===0)
    {
        document.getElementById("s6").innerHTML = "请输入书籍的标签或种类";
        document.getElementById("s6").style.color="red";
    }
    else
    {
        document.getElementById("s6").innerHTML = "";
        document.getElementById("s6").style.color="grey";
    }
    
} 
function blur_bookneirong(txt)
{
    if(txt.value.length===0)
    {
        document.getElementById("s7").innerHTML = "请输入书籍的相关内容";
        document.getElementById("s7").style.color="red";
    }
    else
    {
        document.getElementById("s7").innerHTML = "";
        document.getElementById("s7").style.color="grey";
    }
    
}






function focus_videoname(txt)
{
    document.getElementById("v1").innerHTML = "例：复仇者联盟";
    document.getElementById("v1").style.color="gray";
}
function blur_videoname(txt)
{
    if(txt.value.length===0)
    {
        document.getElementById("v1").innerHTML = "请输入电影的名称";
        document.getElementById("v1").style.color="red";
    }
    else
    {
        document.getElementById("v1").innerHTML = "";
        document.getElementById("v1").style.color="grey";
    }
    
}
function focus_videoauthor(txt)
{
    document.getElementById("v2").innerHTML = "例：乔斯·韦登";
    document.getElementById("v2").style.color="gray";
}
function blur_videoauthor(txt)
{
    if(txt.value.length===0)
    {
        document.getElementById("v2").innerHTML = "请输入电影的导演";
        document.getElementById("v2").style.color="red";
    }
    else
    {
        document.getElementById("v2").innerHTML = "";
        document.getElementById("v2").style.color="grey";
    }
    
}
function focus_videoyanyuan(txt)
{
    document.getElementById("v3").innerHTML = "例：小罗伯特·唐尼,克里斯·埃文斯等";
    document.getElementById("v3").style.color="gray";
}
function blur_videoyanyuan(txt)
{
    if(txt.value.length===0)
    {
        document.getElementById("v3").innerHTML = "请输入电影的演员";
        document.getElementById("v3").style.color="red";
    }
    else
    {
        document.getElementById("v3").innerHTML = "";
        document.getElementById("v3").style.color="grey";
    }
    
}
function focus_videolanguage(txt)
{
    document.getElementById("v4").innerHTML = "例：英语";
    document.getElementById("v4").style.color="gray";
}
function blur_videolanguage(txt)
{
    if(txt.value.length===0)
    {
        document.getElementById("v4").innerHTML = "请输入电影的语言";
        document.getElementById("v4").style.color="red";
    }
    else
    {
        document.getElementById("v4").innerHTML = "";
        document.getElementById("v4").style.color="grey";
    }
    
}
function focus_videotime(txt)
{
    document.getElementById("v5").innerHTML = "例：142(分钟)";
    document.getElementById("v5").style.color="gray";
}
function blur_videotime(txt)
{
    var reg = new RegExp("^[0-9]{1,30}$");
    if(txt.value.length===0)
    {
        document.getElementById("v5").innerHTML = "请输入电影的时长(分钟)";
        document.getElementById("v5").style.color="red";
    } 
    else if(reg.test(txt.value))
    {
        document.getElementById("v5").innerHTML = "";
        document.getElementById("v5").style.color="grey";
    } 
    else
    {
        document.getElementById("v5").innerHTML = "输入正确的数字";
        document.getElementById("v5").style.color="red";
    }
    
}
function focus_videotype(txt)
{
    document.getElementById("v6").innerHTML = "例：科幻动作";
    document.getElementById("v6").style.color="gray";
}
function blur_videotype(txt)
{
    if(txt.value.length===0)
    {
        document.getElementById("v6").innerHTML = "请输入电影的类型";
        document.getElementById("v6").style.color="red";
    }
    else
    {
        document.getElementById("s6").innerHTML = "";
        document.getElementById("s6").style.color="grey";
    }
    
}

function blur_videoneirong(txt)
{
    if(txt.value.length===0)
    {
        document.getElementById("v7").innerHTML = "请输入电影的相关内容";
        document.getElementById("v7").style.color="red";
    }
    else
    {
        document.getElementById("v7").innerHTML = "";
        document.getElementById("v7").style.color="grey";
    }
    
}







function focus_musicname(txt)
{
    document.getElementById("m1").innerHTML = "例：义勇军进行曲";
    document.getElementById("m1").style.color="gray";
}
function blur_musicname(txt)
{
    if(txt.value.length===0)
    {
        document.getElementById("m1").innerHTML = "请输入歌曲的名称";
        document.getElementById("m1").style.color="red";
    }
    else
    {
        document.getElementById("m1").innerHTML = "";
        document.getElementById("m1").style.color="grey";
    }
    
}
function focus_musicwordauthor(txt)
{
    document.getElementById("m2").innerHTML = "例：田汉";
    document.getElementById("m2").style.color="gray";
}
function blur_musicwordauthor(txt)
{
    if(txt.value.length===0)
    {
        document.getElementById("m2").innerHTML = "请输入歌曲的词作者";
        document.getElementById("m2").style.color="red";
    }
    else
    {
        document.getElementById("m2").innerHTML = "";
        document.getElementById("m2").style.color="grey";
    }
    
}
function focus_musicsongwriter(txt)
{
    document.getElementById("m3").innerHTML = "例：聂耳";
    document.getElementById("m3").style.color="gray";
}
function blur_musicsongwriter(txt)
{
    if(txt.value.length===0)
    {
        document.getElementById("m3").innerHTML = "请输入歌曲的曲作者";
        document.getElementById("m3").style.color="red";
    }
    else
    {
        document.getElementById("m3").innerHTML = "";
        document.getElementById("m3").style.color="grey";
    }
    
}
function focus_musicsinger(txt)
{
    document.getElementById("m4").innerHTML = "例：电通公司歌唱队";
    document.getElementById("m4").style.color="gray";
}
function blur_musicsinger(txt)
{
    if(txt.value.length===0)
    {
        document.getElementById("m4").innerHTML = "请输入歌曲的演唱者";
        document.getElementById("m4").style.color="red";
    }
    else
    {
        document.getElementById("m4").innerHTML = "";
        document.getElementById("m4").style.color="grey";
    }
    
}
function focus_musicalbum(txt)
{
    document.getElementById("m5").innerHTML = "现代最流行歌曲选古今中外民歌集";
    document.getElementById("m5").style.color="gray";
}
function blur_musicalbum(txt)
{
    if(txt.value.length===0)
    {
        document.getElementById("m5").innerHTML = "请输入歌曲所属专辑";
        document.getElementById("m5").style.color="red";
    }
    else
    {
        document.getElementById("m5").innerHTML = "";
        document.getElementById("m5").style.color="grey";
    }
}
function focus_musictype(txt)
{
    document.getElementById("m6").innerHTML = "例：励志激昂";
    document.getElementById("m6").style.color="gray";
}
function blur_musictype(txt)
{
    if(txt.value.length===0)
    {
        document.getElementById("m6").innerHTML = "请输入歌曲的类型";
        document.getElementById("m6").style.color="red";
    }
    else
    {
        document.getElementById("m6").innerHTML = "";
        document.getElementById("m6").style.color="grey";
    }
    
}

function focus_musiclink(txt)
{
    document.getElementById("m7").innerHTML = "例：https://music.163.com/#/song?id=395749&autoplay=true&market=baiduhd";
    document.getElementById("m7").style.color="gray";
}
function blur_musiclink(txt)
{
    if(txt.value.length===0)
    {
        document.getElementById("m7").innerHTML = "请输入歌曲的试听链接";
        document.getElementById("m7").style.color="red";
    }
    else
    {
        document.getElementById("m7").innerHTML = "";
        document.getElementById("m7").style.color="grey";
    }
    
}
function blur_musicneirong(txt)
{
    if(txt.value.length===0)
    {
        document.getElementById("m8").innerHTML = "请输入歌词";
        document.getElementById("m8").style.color="red";
    }
    else
    {
        document.getElementById("m8").innerHTML = "";
        document.getElementById("m8").style.color="grey";
    }
    
}





